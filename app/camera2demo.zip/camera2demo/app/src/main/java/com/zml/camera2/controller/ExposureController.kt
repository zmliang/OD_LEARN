package com.zml.camera2.controller

import android.hardware.camera2.CaptureRequest

/**
 * 曝光控制器
 */
class ExposureController {
    
    enum class ExposureMode {
        AUTO, MANUAL
    }
    
    var exposureMode = ExposureMode.AUTO
        private set
    
    var manualExposure = 0L
        private set
    
    fun setExposureMode(mode: ExposureMode) {
        exposureMode = mode
    }
    
    fun setManualExposure(exposure: Long) {
        manualExposure = exposure
    }
    
    /**
     * 应用曝光设置到CaptureRequest.Builder
     */
    fun applyToRequest(builder: CaptureRequest.Builder) {
        if (exposureMode == ExposureMode.MANUAL) {
            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            builder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, manualExposure)
        } else {
            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
        }
    }
}

