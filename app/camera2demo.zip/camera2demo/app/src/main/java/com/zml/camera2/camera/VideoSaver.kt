package com.zml.camera2.camera

import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * 视频保存器，负责保存视频到媒体库
 */
class VideoSaver(private val context: Context) {
    
    fun createVideoFile(): File {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val filename = "VID_${timestamp}.mp4"
        
        val moviesDir = context.getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES)
            ?: context.filesDir
        return File(moviesDir, filename)
    }
    
    fun saveVideoToMediaStore(file: File, onSaved: (File) -> Unit) {
        try {
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val filename = "VID_${timestamp}.mp4"
            
            val contentValues = android.content.ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, filename)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_DCIM}/Camera")
                }
            }
            
            val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues)
            uri?.let {
                context.contentResolver.openOutputStream(it)?.use { output ->
                    file.inputStream().use { input ->
                        input.copyTo(output)
                    }
                }
                file.delete()
                onSaved(File(filename))
            } ?: run {
                Log.e(TAG, "Failed to create MediaStore entry")
                onSaved(file)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error saving video to MediaStore", e)
            onSaved(file)
        }
    }
    
    companion object {
        private const val TAG = "VideoSaver"
    }
}

