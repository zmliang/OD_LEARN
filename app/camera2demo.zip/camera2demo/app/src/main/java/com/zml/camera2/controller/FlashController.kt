package com.zml.camera2.controller

import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest

/**
 * 闪光灯控制器
 */
class FlashController {
    
    enum class FlashMode {
        OFF, ON, AUTO
    }
    
    var flashMode = FlashMode.OFF
        private set
    
    /**
     * 切换到下一个闪光灯模式
     */
    fun cycleFlashMode() {
        flashMode = when (flashMode) {
            FlashMode.OFF -> FlashMode.ON
            FlashMode.ON -> FlashMode.AUTO
            FlashMode.AUTO -> FlashMode.OFF
        }
    }
    
    /**
     * 设置闪光灯模式
     */
    fun setFlashMode(mode: FlashMode) {
        flashMode = mode
    }
    
    /**
     * 应用闪光灯设置到CaptureRequest.Builder
     * 注意：AUTO模式需要设置CONTROL_AE_MODE_ON_AUTO_FLASH
     */
    fun applyToRequest(builder: CaptureRequest.Builder) {
        when (flashMode) {
            FlashMode.OFF -> {
                builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_OFF)
            }
            FlashMode.ON -> {
                builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_SINGLE)
            }
            FlashMode.AUTO -> {
                // AUTO模式：使用CONTROL_AE_MODE_ON_AUTO_FLASH来实现自动闪光
                // 注意：这会覆盖ExposureController的设置，所以需要在ExposureController之后应用
                builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_OFF)
                builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH)
            }
        }
    }
}

