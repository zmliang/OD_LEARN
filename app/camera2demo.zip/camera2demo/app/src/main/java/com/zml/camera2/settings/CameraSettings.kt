package com.zml.camera2.settings

import com.zml.camera2.controller.*

/**
 * 相机设置数据类
 */
data class CameraSettings(
    var flashMode: FlashController.FlashMode = FlashController.FlashMode.OFF,
    var focusMode: FocusController.FocusMode = FocusController.FocusMode.CONTINUOUS,
    var exposureMode: ExposureController.ExposureMode = ExposureController.ExposureMode.AUTO,
    var manualExposure: Long = 0L,
    var whiteBalanceMode: WhiteBalanceController.WhiteBalanceMode = WhiteBalanceController.WhiteBalanceMode.AUTO,
    var manualWhiteBalance: Int = 0,
    var aspectRatio: AspectRatio = AspectRatio.RATIO_16_9,
    var zoom: Float = 1.0f,
    var showGridLines: Boolean = false,
    var enableFaceDetection: Boolean = false
) {
    enum class AspectRatio {
        RATIO_16_9,
        RATIO_4_3,
        RATIO_1_1
    }
}

