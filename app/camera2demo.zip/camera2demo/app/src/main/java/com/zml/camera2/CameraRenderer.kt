package com.zml.camera2

import android.graphics.SurfaceTexture
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class CameraRenderer : GLSurfaceView.Renderer {
    
    private var cameraTextureId = -1
    private var surfaceTexture: SurfaceTexture? = null
    private val vertexBuffer = createQuadVertices()
    private val texCoordBuffer = createQuadTexCoords()
    
    private val TEXTURE_TARGET = android.opengl.GLES11Ext.GL_TEXTURE_EXTERNAL_OES
    
    private var program = -1
    private var aPositionHandle = -1
    private var aTexCoordHandle = -1
    private var uMVPMatrixHandle = -1
    private var uTexMatrixHandle = -1
    private var uTextureHandle = -1
    private var uFilterHandle = -1
    
    private val mvpMatrix = FloatArray(16)
    private val texMatrix = FloatArray(16)
    
    private var filter = Filter.NORMAL
    private var aspectRatio = 1.0f
    private var currentAspectRatio = 1.0f
    private var faces = emptyList<FaceRect>()
    private var showGridLines = false
    private var zoom = 1.0f
    
    fun setCameraTexture(textureId: Int) {
        cameraTextureId = textureId
        if (textureId >= 0) {
            surfaceTexture = SurfaceTexture(textureId)
            Matrix.setIdentityM(texMatrix, 0)
        }
    }
    
    fun getSurfaceTexture(): SurfaceTexture? = surfaceTexture
    
    fun updateTexImage() {
        surfaceTexture?.updateTexImage()
        surfaceTexture?.getTransformMatrix(texMatrix)
    }
    
    fun setFilter(filter: Filter) {
        this.filter = filter
    }
    
    fun setAspectRatio(width: Int, height: Int) {
        aspectRatio = if (height != 0) width.toFloat() / height.toFloat() else 1.0f
    }
    
    fun setFaces(faces: List<FaceRect>) {
        this.faces = faces
    }
    
    fun setGridLines(show: Boolean) {
        showGridLines = show
    }
    
    fun setZoom(zoom: Float) {
        this.zoom = zoom
    }
    
    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.0f, 0.0f, 0.0f, 1.0f)
        program = createShaderProgram()
        
        aPositionHandle = GLES20.glGetAttribLocation(program, "aPosition")
        aTexCoordHandle = GLES20.glGetAttribLocation(program, "aTexCoord")
        uMVPMatrixHandle = GLES20.glGetUniformLocation(program, "uMVPMatrix")
        uTexMatrixHandle = GLES20.glGetUniformLocation(program, "uTexMatrix")
        uTextureHandle = GLES20.glGetUniformLocation(program, "uTexture")
        uFilterHandle = GLES20.glGetUniformLocation(program, "uFilter")
        
        Matrix.setIdentityM(mvpMatrix, 0)
        Matrix.setIdentityM(texMatrix, 0)
    }
    
    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        currentAspectRatio = if (height != 0) width.toFloat() / height.toFloat() else 1.0f
        updateMVPMatrix()
    }
    
    private fun updateMVPMatrix() {
        Matrix.setIdentityM(mvpMatrix, 0)
        
        val viewAspect = currentAspectRatio
        val cameraAspect = aspectRatio
        
        var scaleX = 1.0f
        var scaleY = 1.0f
        
        if (cameraAspect > viewAspect) {
            scaleY = viewAspect / cameraAspect
        } else {
            scaleX = cameraAspect / viewAspect
        }
        
        Matrix.scaleM(mvpMatrix, 0, scaleX * zoom, scaleY * zoom, 1.0f)
    }
    
    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        
        if (cameraTextureId < 0 || program < 0) return
        
        updateMVPMatrix()
        
        GLES20.glUseProgram(program)
        
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(TEXTURE_TARGET, cameraTextureId)
        GLES20.glUniform1i(uTextureHandle, 0)
        
        GLES20.glUniformMatrix4fv(uMVPMatrixHandle, 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(uTexMatrixHandle, 1, false, texMatrix, 0)
        GLES20.glUniform1i(uFilterHandle, filter.ordinal)
        
        vertexBuffer.position(0)
        GLES20.glEnableVertexAttribArray(aPositionHandle)
        GLES20.glVertexAttribPointer(aPositionHandle, 2, GLES20.GL_FLOAT, false, 0, vertexBuffer)
        
        texCoordBuffer.position(0)
        GLES20.glEnableVertexAttribArray(aTexCoordHandle)
        GLES20.glVertexAttribPointer(aTexCoordHandle, 2, GLES20.GL_FLOAT, false, 0, texCoordBuffer)
        
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        
        GLES20.glDisableVertexAttribArray(aPositionHandle)
        GLES20.glDisableVertexAttribArray(aTexCoordHandle)
        
        if (showGridLines) {
            drawGridLines()
        }
        
        if (faces.isNotEmpty()) {
            drawFaceRects()
        }
    }
    
    private fun drawGridLines() {
        // 实现网格线绘制
        // 这里简化实现，实际需要额外的shader和渲染代码
    }
    
    private fun drawFaceRects() {
        // 实现人脸框绘制
        // 这里简化实现，实际需要额外的shader和渲染代码
    }
    
    private fun createShaderProgram(): Int {
        val vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, VERTEX_SHADER)
        val fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, FRAGMENT_SHADER)
        
        val program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vertexShader)
        GLES20.glAttachShader(program, fragmentShader)
        GLES20.glLinkProgram(program)
        
        val linkStatus = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, linkStatus, 0)
        if (linkStatus[0] != GLES20.GL_TRUE) {
            GLES20.glDeleteProgram(program)
            throw RuntimeException("Could not link program: ${GLES20.glGetProgramInfoLog(program)}")
        }
        
        return program
    }
    
    private fun loadShader(type: Int, shaderCode: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, shaderCode)
        GLES20.glCompileShader(shader)
        
        val compiled = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compiled, 0)
        if (compiled[0] == 0) {
            GLES20.glDeleteShader(shader)
            throw RuntimeException("Could not compile shader: ${GLES20.glGetShaderInfoLog(shader)}")
        }
        
        return shader
    }
    
    private fun createQuadVertices(): java.nio.FloatBuffer {
        val vertices = floatArrayOf(
            -1.0f, -1.0f,
            1.0f, -1.0f,
            -1.0f, 1.0f,
            1.0f, 1.0f
        )
        val buffer = java.nio.ByteBuffer.allocateDirect(vertices.size * 4)
            .order(java.nio.ByteOrder.nativeOrder())
            .asFloatBuffer()
        buffer.put(vertices)
        buffer.position(0)
        return buffer
    }
    
    private fun createQuadTexCoords(): java.nio.FloatBuffer {
        val coords = floatArrayOf(
            0.0f, 1.0f,
            1.0f, 1.0f,
            0.0f, 0.0f,
            1.0f, 0.0f
        )
        val buffer = java.nio.ByteBuffer.allocateDirect(coords.size * 4)
            .order(java.nio.ByteOrder.nativeOrder())
            .asFloatBuffer()
        buffer.put(coords)
        buffer.position(0)
        return buffer
    }
    
    companion object {
        private const val VERTEX_SHADER = """
            attribute vec4 aPosition;
            attribute vec4 aTexCoord;
            uniform mat4 uMVPMatrix;
            uniform mat4 uTexMatrix;
            varying vec2 vTexCoord;
            
            void main() {
                gl_Position = uMVPMatrix * aPosition;
                vTexCoord = (uTexMatrix * aTexCoord).xy;
            }
        """
        
        private const val FRAGMENT_SHADER = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            uniform samplerExternalOES uTexture;
            uniform int uFilter;
            varying vec2 vTexCoord;
            
            void main() {
                vec4 color = texture2D(uTexture, vTexCoord);
                
                if (uFilter == 1) {
                    // Grayscale
                    float gray = dot(color.rgb, vec3(0.299, 0.587, 0.114));
                    color = vec4(gray, gray, gray, color.a);
                } else if (uFilter == 2) {
                    // Sepia
                    color.r = dot(color.rgb, vec3(0.393, 0.769, 0.189));
                    color.g = dot(color.rgb, vec3(0.349, 0.686, 0.168));
                    color.b = dot(color.rgb, vec3(0.272, 0.534, 0.131));
                } else if (uFilter == 3) {
                    // Invert
                    color.rgb = 1.0 - color.rgb;
                } else if (uFilter == 4) {
                    // Vintage
                    color.r *= 1.2;
                    color.b *= 0.8;
                    color = mix(color, vec4(0.9, 0.9, 0.7, 1.0), 0.1);
                }
                
                gl_FragColor = color;
            }
        """
    }
}

enum class Filter {
    NORMAL, GRAYSCALE, SEPIA, INVERT, VINTAGE
}

data class FaceRect(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
)

