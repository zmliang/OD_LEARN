package com.zml.camera2

import android.content.Context
import android.opengl.GLSurfaceView
import android.util.AttributeSet

class CameraGLSurfaceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : GLSurfaceView(context, attrs) {

    val renderer: CameraRenderer

    init {
        setEGLContextClientVersion(2)
        renderer = CameraRenderer()
        setRenderer(renderer)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    fun setCameraTexture(textureId: Int) {
        renderer.setCameraTexture(textureId)
    }

    fun updateTexImage() {
        queueEvent {
            renderer.updateTexImage()
        }
        requestRender()
    }

    fun setFilter(filter: Filter) {
        queueEvent {
            renderer.setFilter(filter)
        }
        requestRender()
    }

    fun setAspectRatio(width: Int, height: Int) {
        queueEvent {
            renderer.setAspectRatio(width, height)
        }
    }

    fun setFaces(faces: List<FaceRect>) {
        queueEvent {
            renderer.setFaces(faces)
        }
        requestRender()
    }

    fun setGridLines(show: Boolean) {
        queueEvent {
            renderer.setGridLines(show)
        }
        requestRender()
    }

    fun setZoom(zoom: Float) {
        queueEvent {
            renderer.setZoom(zoom)
        }
        requestRender()
    }
}

