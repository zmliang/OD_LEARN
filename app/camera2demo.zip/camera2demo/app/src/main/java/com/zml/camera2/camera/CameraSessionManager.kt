package com.zml.camera2.camera

import android.graphics.ImageFormat
import android.hardware.camera2.*
import android.media.ImageReader
import android.os.Handler
import android.util.Log
import android.view.Surface

/**
 * 相机会话管理器，负责创建和管理 CameraCaptureSession
 */
class CameraSessionManager(
    private val cameraController: CameraController,
    private val settings: CameraSettings
) {
    
    private var captureSession: CameraCaptureSession? = null
    private var previewRequestBuilder: CaptureRequest.Builder? = null
    private var imageReader: ImageReader? = null
    
    var onSessionConfigured: ((CameraCaptureSession) -> Unit)? = null
    var onImageAvailable: ImageReader.OnImageAvailableListener? = null
    
    fun createPreviewSession(previewSurface: Surface) {
        try {
            val device = cameraController.getCameraDevice() ?: return
            val previewSize = cameraController.currentPreviewSize ?: return
            val handler = cameraController.getBackgroundHandler() ?: return
            
            imageReader = ImageReader.newInstance(
                previewSize.width,
                previewSize.height,
                ImageFormat.JPEG,
                2
            ).apply {
                onImageAvailable?.let { setOnImageAvailableListener(it, handler) }
            }
            
            previewRequestBuilder = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                addTarget(previewSurface)
                applySettings(this)
            }
            
            device.createCaptureSession(
                listOf(previewSurface, imageReader?.surface!!),
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(session: CameraCaptureSession) {
                        captureSession = session
                        onSessionConfigured?.invoke(session)
                        updatePreviewRequest()
                    }
                    
                    override fun onConfigureFailed(session: CameraCaptureSession) {
                        Log.e(TAG, "Capture session configuration failed")
                    }
                },
                handler
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error creating preview session", e)
        }
    }
    
    fun createRecordingSession(previewSurface: Surface, recorderSurface: Surface) {
        try {
            val device = cameraController.getCameraDevice() ?: return
            val handler = cameraController.getBackgroundHandler() ?: return
            
            captureSession?.close()
            captureSession = null
            
            previewRequestBuilder = device.createCaptureRequest(CameraDevice.TEMPLATE_RECORD).apply {
                addTarget(previewSurface)
                addTarget(recorderSurface)
                applySettings(this)
            }
            
            device.createCaptureSession(
                listOf(previewSurface, recorderSurface),
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(session: CameraCaptureSession) {
                        captureSession = session
                        onSessionConfigured?.invoke(session)
                        updatePreviewRequest()
                    }
                    
                    override fun onConfigureFailed(session: CameraCaptureSession) {
                        Log.e(TAG, "Recording session configuration failed")
                    }
                },
                handler
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error creating recording session", e)
        }
    }
    
    fun updatePreviewRequest() {
        previewRequestBuilder?.let { builder ->
            applySettings(builder)
            captureSession?.setRepeatingRequest(builder.build(), null, cameraController.getBackgroundHandler())
        }
    }
    
    private fun applySettings(builder: CaptureRequest.Builder) {
        // Flash mode
        when (settings.flashMode) {
            CameraSettings.FlashMode.OFF -> {
                builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_OFF)
            }
            CameraSettings.FlashMode.ON -> {
                builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_SINGLE)
            }
            CameraSettings.FlashMode.AUTO -> {
                // AUTO模式使用CONTROL_AE_MODE_ON_AUTO_FLASH
                builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_OFF)
                builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH)
            }
        }
        
        // Focus mode
        when (settings.focusMode) {
            CameraSettings.FocusMode.AUTO -> {
                builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO)
            }
            CameraSettings.FocusMode.CONTINUOUS -> {
                builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            }
            CameraSettings.FocusMode.MANUAL -> {
                // Manual focus handled by touch focus
            }
        }
        
        // Exposure mode
        if (settings.exposureMode == CameraSettings.ExposureMode.MANUAL) {
            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            builder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, settings.manualExposure)
        } else {
            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
        }
        
        // White balance mode
        if (settings.whiteBalanceMode == CameraSettings.WhiteBalanceMode.MANUAL) {
            builder.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_OFF)
            builder.set(CaptureRequest.COLOR_CORRECTION_MODE, CaptureRequest.COLOR_CORRECTION_MODE_TRANSFORM_MATRIX)
        } else {
            builder.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
        }
        
        // Zoom
        if (settings.zoom > 1.0f) {
            val rect = calculateZoomRect(settings.zoom)
            builder.set(CaptureRequest.SCALER_CROP_REGION, rect)
        }
    }
    
    private fun calculateZoomRect(zoom: Float): android.graphics.Rect {
        val characteristics = cameraController.cameraCharacteristics ?: return android.graphics.Rect()
        val sensorArray = characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: return android.graphics.Rect()
        
        val centerX = sensorArray.centerX()
        val centerY = sensorArray.centerY()
        val width = (sensorArray.width() / zoom).toInt()
        val height = (sensorArray.height() / zoom).toInt()
        
        return android.graphics.Rect(
            centerX - width / 2,
            centerY - height / 2,
            centerX + width / 2,
            centerY + height / 2
        )
    }
    
    fun touchFocus(x: Float, y: Float, width: Int, height: Int) {
        val characteristics = cameraController.cameraCharacteristics ?: return
        val focusArea = characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: return
        val previewSize = cameraController.currentPreviewSize ?: return
        
        val normalizedX = x / width
        val normalizedY = y / height
        
        val mappedX = (normalizedX * focusArea.width()).toInt().coerceIn(0, focusArea.width())
        val mappedY = (normalizedY * focusArea.height()).toInt().coerceIn(0, focusArea.height())
        
        val focusRectSize = 200
        val left = (mappedX - focusRectSize / 2).coerceAtLeast(0)
        val top = (mappedY - focusRectSize / 2).coerceAtLeast(0)
        val right = (left + focusRectSize).coerceAtMost(focusArea.width())
        val bottom = (top + focusRectSize).coerceAtMost(focusArea.height())
        
        val meteringRect = android.hardware.camera2.params.MeteringRectangle(
            android.graphics.Rect(left, top, right, bottom),
            1000
        )
        
        previewRequestBuilder?.apply {
            set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_CANCEL)
            set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO)
            set(CaptureRequest.CONTROL_AF_REGIONS, arrayOf(meteringRect))
            set(CaptureRequest.CONTROL_AE_REGIONS, arrayOf(meteringRect))
            set(CaptureRequest.CONTROL_AWB_REGIONS, arrayOf(meteringRect))
            set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_START)
            
            captureSession?.capture(build(), object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(
                    session: CameraCaptureSession,
                    request: CaptureRequest,
                    result: TotalCaptureResult
                ) {
                    updatePreviewRequest()
                }
            }, cameraController.getBackgroundHandler())
        }
    }
    
    fun getImageReader(): ImageReader? = imageReader
    
    fun getCaptureSession(): CameraCaptureSession? = captureSession
    
    fun closeSession() {
        captureSession?.close()
        captureSession = null
        imageReader?.close()
        imageReader = null
    }
    
    companion object {
        private const val TAG = "CameraSessionManager"
    }
}

