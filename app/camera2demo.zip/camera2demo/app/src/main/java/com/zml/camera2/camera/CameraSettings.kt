package com.zml.camera2.camera

/**
 * 相机设置配置类，封装所有相机参数设置
 */
data class CameraSettings(
    var flashMode: FlashMode = FlashMode.OFF,
    var focusMode: FocusMode = FocusMode.CONTINUOUS,
    var exposureMode: ExposureMode = ExposureMode.AUTO,
    var manualExposure: Long = 0L,
    var whiteBalanceMode: WhiteBalanceMode = WhiteBalanceMode.AUTO,
    var manualWhiteBalance: Int = 0,
    var aspectRatio: AspectRatio = AspectRatio.RATIO_16_9,
    var zoom: Float = 1.0f
) {
    enum class FlashMode {
        OFF, ON, AUTO
    }
    
    enum class FocusMode {
        AUTO, CONTINUOUS, MANUAL
    }
    
    enum class ExposureMode {
        AUTO, MANUAL
    }
    
    enum class WhiteBalanceMode {
        AUTO, MANUAL
    }
    
    enum class AspectRatio {
        RATIO_16_9, RATIO_4_3, RATIO_1_1
    }
}

