package com.zml.camera2.settings

import android.content.Context
import android.content.SharedPreferences
import com.zml.camera2.controller.*

/**
 * 相机设置管理器
 */
class SettingsManager(private val context: Context) {
    
    private val prefs: SharedPreferences = context.getSharedPreferences(
        "camera_settings",
        Context.MODE_PRIVATE
    )
    
    private val defaultSettings = CameraSettings()
    
    /**
     * 保存设置
     */
    fun saveSettings(settings: CameraSettings) {
        prefs.edit().apply {
            putString("flash_mode", settings.flashMode.name)
            putString("focus_mode", settings.focusMode.name)
            putString("exposure_mode", settings.exposureMode.name)
            putLong("manual_exposure", settings.manualExposure)
            putString("white_balance_mode", settings.whiteBalanceMode.name)
            putInt("manual_white_balance", settings.manualWhiteBalance)
            putString("aspect_ratio", settings.aspectRatio.name)
            putFloat("zoom", settings.zoom)
            putBoolean("show_grid_lines", settings.showGridLines)
            putBoolean("enable_face_detection", settings.enableFaceDetection)
            apply()
        }
    }
    
    /**
     * 加载设置
     */
    fun loadSettings(): CameraSettings {
        return CameraSettings(
            flashMode = FlashController.FlashMode.valueOf(
                prefs.getString("flash_mode", defaultSettings.flashMode.name) ?: defaultSettings.flashMode.name
            ),
            focusMode = FocusController.FocusMode.valueOf(
                prefs.getString("focus_mode", defaultSettings.focusMode.name) ?: defaultSettings.focusMode.name
            ),
            exposureMode = ExposureController.ExposureMode.valueOf(
                prefs.getString("exposure_mode", defaultSettings.exposureMode.name) ?: defaultSettings.exposureMode.name
            ),
            manualExposure = prefs.getLong("manual_exposure", defaultSettings.manualExposure),
            whiteBalanceMode = WhiteBalanceController.WhiteBalanceMode.valueOf(
                prefs.getString("white_balance_mode", defaultSettings.whiteBalanceMode.name) ?: defaultSettings.whiteBalanceMode.name
            ),
            manualWhiteBalance = prefs.getInt("manual_white_balance", defaultSettings.manualWhiteBalance),
            aspectRatio = CameraSettings.AspectRatio.valueOf(
                prefs.getString("aspect_ratio", defaultSettings.aspectRatio.name) ?: defaultSettings.aspectRatio.name
            ),
            zoom = prefs.getFloat("zoom", defaultSettings.zoom),
            showGridLines = prefs.getBoolean("show_grid_lines", defaultSettings.showGridLines),
            enableFaceDetection = prefs.getBoolean("enable_face_detection", defaultSettings.enableFaceDetection)
        )
    }
    
    /**
     * 重置为默认设置
     */
    fun resetToDefault(): CameraSettings {
        val settings = defaultSettings
        saveSettings(settings)
        return settings
    }
}

