package com.zml.camera2.camera

import android.content.Context
import android.hardware.camera2.*
import android.os.Handler
import android.util.Log
import android.view.Surface

/**
 * 拍照管理器，负责处理拍照相关操作
 */
class ImageCaptureManager(
    private val sessionManager: CameraSessionManager,
    private val cameraController: CameraController,
    private val settings: CameraSettings,
    private val context: Context
) {
    
    var onPhotoCaptured: ((String) -> Unit)? = null
    
    fun takePicture(shutterSound: Boolean = true) {
        try {
            if (shutterSound) {
                playShutterSound()
            }
            
            val device = cameraController.getCameraDevice() ?: return
            val session = sessionManager.getCaptureSession() ?: return
            val imageReader = sessionManager.getImageReader() ?: return
            val handler = cameraController.getBackgroundHandler() ?: return
            
            val captureBuilder = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                addTarget(imageReader.surface)
                applyCaptureSettings(this)
                set(CaptureRequest.JPEG_ORIENTATION, getJpegOrientation())
            }
            
            session.stopRepeating()
            session.capture(captureBuilder.build(), object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(
                    session: CameraCaptureSession,
                    request: CaptureRequest,
                    result: TotalCaptureResult
                ) {
                    sessionManager.updatePreviewRequest()
                }
            }, handler)
        } catch (e: Exception) {
            Log.e(TAG, "Error taking picture", e)
        }
    }
    
    private fun applyCaptureSettings(builder: CaptureRequest.Builder) {
        // Flash mode for capture
        when (settings.flashMode) {
            CameraSettings.FlashMode.OFF -> {
                builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_OFF)
            }
            CameraSettings.FlashMode.ON -> {
                builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_SINGLE)
            }
            CameraSettings.FlashMode.AUTO -> {
                // AUTO模式使用CONTROL_AE_MODE_ON_AUTO_FLASH来实现自动闪光
                builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_OFF)
                builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH)
            }
        }
    }
    
    private fun playShutterSound() {
        val toneGenerator = android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 100)
        toneGenerator.startTone(android.media.ToneGenerator.TONE_PROP_BEEP)
    }
    
    private fun getJpegOrientation(): Int {
        val rotation = if (context is android.app.Activity) {
            context.windowManager.defaultDisplay.rotation
        } else {
            0
        }
        
        val characteristics = cameraController.cameraCharacteristics ?: return 0
        val sensorOrientation = characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 0
        val facing = characteristics.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
        
        return when (rotation) {
            Surface.ROTATION_0 -> if (facing) (360 - sensorOrientation) % 360 else sensorOrientation
            Surface.ROTATION_90 -> if (facing) (270 - sensorOrientation + 360) % 360 else (sensorOrientation + 90) % 360
            Surface.ROTATION_180 -> if (facing) (180 - sensorOrientation + 360) % 360 else (sensorOrientation + 180) % 360
            Surface.ROTATION_270 -> if (facing) (90 - sensorOrientation + 360) % 360 else (sensorOrientation + 270) % 360
            else -> sensorOrientation
        }
    }
    
    companion object {
        private const val TAG = "ImageCaptureManager"
    }
}

