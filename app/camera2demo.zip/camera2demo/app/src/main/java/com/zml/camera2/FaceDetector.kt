package com.zml.camera2

import android.graphics.Rect
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.params.Face
import android.util.Size

/**
 * 使用Camera2自带的人脸检测功能
 */
class FaceDetector {
    
    private var previewSize: Size? = null
    private var sensorArraySize: Size? = null
    
    var onFacesDetected: ((List<FaceRect>) -> Unit)? = null
    
    /**
     * 检查相机是否支持人脸检测
     */
    fun isFaceDetectionSupported(characteristics: CameraCharacteristics): Boolean {
        val modes = characteristics.get(CameraCharacteristics.STATISTICS_INFO_AVAILABLE_FACE_DETECT_MODES)
        return modes != null && modes.isNotEmpty() && 
               modes.contains(CameraMetadata.STATISTICS_FACE_DETECT_MODE_SIMPLE)
    }
    
    /**
     * 获取支持的人脸检测模式
     */
    fun getAvailableFaceDetectModes(characteristics: CameraCharacteristics): IntArray? {
        return characteristics.get(CameraCharacteristics.STATISTICS_INFO_AVAILABLE_FACE_DETECT_MODES)
    }
    
    /**
     * 获取最大可检测的人脸数量
     */
    fun getMaxFaceCount(characteristics: CameraCharacteristics): Int {
        return characteristics.get(CameraCharacteristics.STATISTICS_INFO_MAX_FACE_COUNT) ?: 0
    }
    
    /**
     * 设置预览尺寸，用于坐标转换
     */
    fun setPreviewSize(size: Size?) {
        previewSize = size
    }
    
    /**
     * 设置传感器尺寸，用于坐标转换
     */
    fun setSensorArraySize(size: Size?) {
        sensorArraySize = size
    }
    
    /**
     * 启用人脸检测到CaptureRequest.Builder
     */
    fun enableFaceDetection(builder: CaptureRequest.Builder, mode: Int = CameraMetadata.STATISTICS_FACE_DETECT_MODE_SIMPLE) {
        builder.set(CaptureRequest.STATISTICS_FACE_DETECT_MODE, mode)
    }
    
    /**
     * 从CaptureResult中提取人脸检测结果
     */
    fun processFaceDetectionResult(result: CaptureResult): List<FaceRect> {
        val faces = result.get(CaptureResult.STATISTICS_FACES) ?: return emptyList()
        val previewSize = this.previewSize ?: return emptyList()
        val sensorArraySize = this.sensorArraySize ?: return emptyList()
        
        return faces.map { face ->
            convertFaceToRect(face, previewSize, sensorArraySize)
        }
    }
    
    /**
     * 将Camera2的Face转换为归一化的FaceRect
     * Camera2返回的坐标是在sensor坐标系中，需要转换为预览坐标
     */
    private fun convertFaceToRect(face: Face, previewSize: Size, sensorArraySize: Size): FaceRect {
        val bounds = face.bounds
        
        // 将sensor坐标转换为预览坐标
        // sensor坐标范围是 [0, sensorArraySize.width/height]
        // 预览坐标范围是 [0, previewSize.width/height]
        // 然后归一化到 [0, 1]
        
        val scaleX = previewSize.width.toFloat() / sensorArraySize.width
        val scaleY = previewSize.height.toFloat() / sensorArraySize.height
        
        val left = (bounds.left * scaleX / previewSize.width).coerceIn(0f, 1f)
        val top = (bounds.top * scaleY / previewSize.height).coerceIn(0f, 1f)
        val right = (bounds.right * scaleX / previewSize.width).coerceIn(0f, 1f)
        val bottom = (bounds.bottom * scaleY / previewSize.height).coerceIn(0f, 1f)
        
        return FaceRect(
            left = left,
            top = top,
            right = right,
            bottom = bottom
        )
    }
    
    /**
     * 关闭人脸检测（清理资源，Camera2不需要特殊清理）
     */
    fun close() {
        // Camera2的人脸检测不需要特殊清理
    }
}
