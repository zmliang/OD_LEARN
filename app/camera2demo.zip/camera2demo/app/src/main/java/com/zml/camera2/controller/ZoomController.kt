package com.zml.camera2.controller

import android.graphics.Rect
import android.hardware.camera2.CaptureRequest
import android.util.Size

/**
 * 缩放控制器
 */
class ZoomController {
    
    private var maxZoom: Float = 1.0f
    private var currentZoom: Float = 1.0f
    private var sensorArraySize: Size? = null
    
    fun setMaxZoom(zoom: Float) {
        maxZoom = zoom
    }
    
    fun setSensorArraySize(size: Size?) {
        sensorArraySize = size
    }
    
    fun setZoom(zoom: Float) {
        currentZoom = zoom.coerceIn(1.0f, maxZoom)
    }
    
    fun getCurrentZoom(): Float = currentZoom
    
    fun getMaxZoom(): Float = maxZoom
    
    /**
     * 应用缩放设置到CaptureRequest.Builder
     */
    fun applyToRequest(builder: CaptureRequest.Builder) {
        if (currentZoom > 1.0f) {
            val rect = calculateZoomRect(currentZoom)
            builder.set(CaptureRequest.SCALER_CROP_REGION, rect)
        }
    }
    
    private fun calculateZoomRect(zoom: Float): Rect {
        val sensorArray = sensorArraySize ?: return Rect()
        
        val centerX = sensorArray.width / 2
        val centerY = sensorArray.height / 2
        val width = (sensorArray.width / zoom).toInt()
        val height = (sensorArray.height / zoom).toInt()
        
        return Rect(
            centerX - width / 2,
            centerY - height / 2,
            centerX + width / 2,
            centerY + height / 2
        )
    }
}

