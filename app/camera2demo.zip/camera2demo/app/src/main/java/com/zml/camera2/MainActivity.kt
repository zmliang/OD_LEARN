package com.zml.camera2

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.zml.camera2.controller.*
import com.zml.camera2.databinding.ActivityMainBinding
import com.zml.camera2.preview.GLSurfaceViewPreviewView
import com.zml.camera2.preview.IPreviewView
import com.zml.camera2.preview.PreviewViewFactory
import com.zml.camera2.settings.CameraSettings
import com.zml.camera2.viewmodel.CameraViewModel
import java.io.File
import java.util.*
import kotlin.math.sqrt

/**
 * 主Activity - 负责UI交互和生命周期管理
 */
class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: CameraViewModel
    
    private var countdownTimer: Timer? = null
    private var countdownSeconds = 0
    
    // Zoom gesture state
    private var lastZoomDistance = 0f
    private var baseZoom = 1.0f
    
    private val requiredPermissions = arrayOf(
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO,
    )
    
    private val permissionRequestCode = 1001
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        viewModel = ViewModelProvider(this)[CameraViewModel::class.java]
        
        setupUI()
        observeViewModel()
        
        if (checkPermissions()) {
            initializeCamera()
        } else {
            requestPermissions()
        }
    }
    
    private fun setupUI() {
        setupSpinners()
        setupButtons()

        setupPreviewContainer()
    }
    
    private fun setupSpinners() {
        // Focus Mode Spinner
        val focusModes = arrayOf("Auto", "Continuous", "Manual")
        val focusAdapter = android.widget.ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            focusModes
        )
        focusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerFocus.adapter = focusAdapter
        binding.spinnerFocus.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                viewModel.setFocusMode(FocusController.FocusMode.values()[position])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        
        // Exposure Mode Spinner
        val exposureModes = arrayOf("Auto", "Manual")
        val exposureAdapter = android.widget.ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            exposureModes
        )
        exposureAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerExposure.adapter = exposureAdapter
        binding.spinnerExposure.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                viewModel.setExposureMode(ExposureController.ExposureMode.values()[position])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        
        // White Balance Spinner
        val whiteBalanceModes = arrayOf("Auto", "Manual")
        val whiteBalanceAdapter = android.widget.ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            whiteBalanceModes
        )
        whiteBalanceAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerWhiteBalance.adapter = whiteBalanceAdapter
        binding.spinnerWhiteBalance.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                viewModel.setWhiteBalanceMode(WhiteBalanceController.WhiteBalanceMode.values()[position])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        
        // Aspect Ratio Spinner
        val aspectRatios = arrayOf("16:9", "4:3", "1:1")
        val aspectRatioAdapter = android.widget.ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            aspectRatios
        )
        aspectRatioAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerAspectRatio.adapter = aspectRatioAdapter
        binding.spinnerAspectRatio.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val ratio = CameraSettings.AspectRatio.values()[position]
                viewModel.setAspectRatio(ratio)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }
    
    private fun setupButtons() {
        binding.btnSwitchCamera.setOnClickListener {
            viewModel.switchCamera()
        }
        
        binding.btnFlash.setOnClickListener {
            viewModel.cycleFlashMode()
        }
        
        binding.btnFilter.setOnClickListener {
            viewModel.cycleFilter()
        }
        
        binding.btnSettings.setOnClickListener {
            binding.settingsPanel.visibility = if (binding.settingsPanel.visibility == View.VISIBLE) {
                View.GONE
            } else {
                View.VISIBLE
            }
        }
        
        binding.btnCapture.setOnClickListener {
            if (countdownSeconds > 0) {
                startCountdown(countdownSeconds) {
                    viewModel.takePicture()
                }
            } else {
                viewModel.takePicture()
            }
        }
        
        binding.btnRecord.setOnClickListener {
            if (viewModel.isRecording.value == true) {
                viewModel.stopRecording()
            } else {
                viewModel.startRecording()
            }
        }
        
        binding.checkboxGridLines.setOnCheckedChangeListener { _, isChecked ->
            viewModel.setGridLines(isChecked)
        }
        
        binding.checkboxFaceDetection.setOnCheckedChangeListener { _, isChecked ->
            viewModel.setFaceDetection(isChecked)
            // Camera2自带人脸检测不需要额外的ImageReader
            // 人脸检测结果会通过CaptureResult回调获取
        }
        
        binding.btnTimer3.setOnClickListener { countdownSeconds = 3 }
        binding.btnTimer5.setOnClickListener { countdownSeconds = 5 }
        binding.btnTimer10.setOnClickListener { countdownSeconds = 10 }
    }

    private var previewView: IPreviewView? = null
    private fun setupPreviewContainer() {
        previewView = PreviewViewFactory.create(this, PreviewViewFactory.PreviewType.TEXTURE_VIEW)
        previewView?.let {
            binding.cameraPreviewContainer.removeAllViews()
            binding.cameraPreviewContainer.addView(it.getView(), ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            
            // Setup touch gesture for zoom and focus
            it.getView().setOnTouchListener { view, event ->
                handleTouchEvent(view, event)
                true
            }
        }
    }
    
    private fun handleTouchEvent(view: View, event: MotionEvent): Boolean {
        when (event.action and MotionEvent.ACTION_MASK) {
            MotionEvent.ACTION_DOWN -> {
                if (event.pointerCount == 1) {
                    // Single touch - focus
                    val x = event.x
                    val y = event.y
                    viewModel.touchFocus(x, y, view.width, view.height)
                }
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (event.pointerCount == 2) {
                    // Two fingers - start zoom
                    val distance = getDistance(event)
                    lastZoomDistance = distance
                    baseZoom = viewModel.getCurrentZoom()
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount == 2) {
                    // Two fingers - zoom
                    val distance = getDistance(event)
                    val scale = distance / lastZoomDistance
                    val newZoom = (baseZoom * scale).coerceIn(1.0f, viewModel.getMaxZoom())
                    viewModel.setZoom(newZoom)
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (event.pointerCount == 1) {
                    baseZoom = viewModel.getCurrentZoom()
                }
            }
        }
        return true
    }
    
    private fun getDistance(event: MotionEvent): Float {
        val dx = event.getX(0) - event.getX(1)
        val dy = event.getY(0) - event.getY(1)
        return sqrt(dx * dx + dy * dy)
    }
    
    private fun observeViewModel() {
        viewModel.photoCaptured.observe(this) { file ->
            file?.let {
                Toast.makeText(this, "Photo saved: ${it.name}", Toast.LENGTH_SHORT).show()
            }
        }
        
        viewModel.videoRecorded.observe(this) { file ->
            file?.let {
                Toast.makeText(this, "Video saved: ${it.name}", Toast.LENGTH_SHORT).show()
            }
        }
        
        viewModel.isRecording.observe(this) { isRecording ->
            if (isRecording) {
                binding.btnRecord.setImageResource(android.R.drawable.ic_media_pause)
                binding.btnCapture.visibility = View.GONE
            } else {
                binding.btnRecord.setImageResource(android.R.drawable.ic_media_play)
                binding.btnCapture.visibility = View.VISIBLE
            }
        }
        
        viewModel.currentFlashMode.observe(this) { mode ->
            val icon = when (mode) {
                FlashController.FlashMode.OFF -> android.R.drawable.ic_menu_revert
                FlashController.FlashMode.ON -> android.R.drawable.ic_menu_compass
                FlashController.FlashMode.AUTO -> android.R.drawable.ic_menu_info_details
            }
            binding.btnFlash.setImageResource(icon)
        }
        
        viewModel.currentFilter.observe(this) { filter ->
            // Filter UI update if needed
        }
    }
    
    private fun startCountdown(seconds: Int, onComplete: () -> Unit) {
        countdownSeconds = seconds
        countdownTimer?.cancel()
        
        binding.tvCountdown.visibility = View.VISIBLE
        binding.tvCountdown.text = countdownSeconds.toString()
        
        countdownTimer = Timer()
        countdownTimer?.scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                runOnUiThread {
                    countdownSeconds--
                    if (countdownSeconds > 0) {
                        binding.tvCountdown.text = countdownSeconds.toString()
                    } else {
                        binding.tvCountdown.visibility = View.GONE
                        countdownTimer?.cancel()
                        onComplete()
                    }
                }
            }
        }, 1000, 1000)
    }
    
    private fun initializeCamera() {
        viewModel.initialize(previewView)
    }
    
    private fun checkPermissions(): Boolean {
        return requiredPermissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
    }
    
    private fun requestPermissions() {
        ActivityCompat.requestPermissions(this, requiredPermissions, permissionRequestCode)
    }
    
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequestCode) {
            if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                initializeCamera()
            } else {
                AlertDialog.Builder(this)
                    .setTitle("Permissions Required")
                    .setMessage("Camera and storage permissions are required to use this app.")
                    .setPositiveButton("OK") { _, _ -> requestPermissions() }
                    .setNegativeButton("Cancel") { _, _ -> finish() }
                    .show()
            }
        }
    }
    
    override fun onResume() {
        super.onResume()
        // Camera is managed by ViewModel lifecycle
    }
    
    override fun onPause() {
        super.onPause()
        countdownTimer?.cancel()
    }
    
    override fun onDestroy() {
        super.onDestroy()
        countdownTimer?.cancel()
    }
}
