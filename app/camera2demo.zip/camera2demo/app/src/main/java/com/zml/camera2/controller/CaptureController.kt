package com.zml.camera2.controller

import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.TotalCaptureResult
import android.media.ImageReader
import android.os.Handler
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.util.Size
import android.view.Surface
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * 拍照控制器
 */
class CaptureController(
    private val context: Context,
    private val backgroundHandler: Handler
) {
    
    private var imageReader: ImageReader? = null
    private var previewSize: Size? = null
    
    var onPhotoCaptured: ((File) -> Unit)? = null
    
    fun initialize(previewSize: Size) {
        this.previewSize = previewSize
        imageReader = ImageReader.newInstance(
            previewSize.width,
            previewSize.height,
            ImageFormat.JPEG,
            2
        ).apply {
            setOnImageAvailableListener(imageAvailableListener, backgroundHandler)
        }
    }
    
    fun getImageReaderSurface(): Surface? = imageReader?.surface
    
    fun takePicture(
        builder: CaptureRequest.Builder,
        session: CameraCaptureSession,
        shutterSound: Boolean = true
    ) {
        try {
            if (shutterSound) {
                playShutterSound()
            }
            
            session.stopRepeating()
            session.capture(builder.build(), object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(
                    session: CameraCaptureSession,
                    request: CaptureRequest,
                    result: TotalCaptureResult
                ) {
                    // Preview will resume after image is saved
                }
            }, backgroundHandler)
        } catch (e: Exception) {
            Log.e(TAG, "Error taking picture", e)
        }
    }
    
    private fun playShutterSound() {
        val toneGenerator = android.media.ToneGenerator(
            android.media.AudioManager.STREAM_MUSIC,
            100
        )
        toneGenerator.startTone(android.media.ToneGenerator.TONE_PROP_BEEP)
    }
    
    private val imageAvailableListener = ImageReader.OnImageAvailableListener { reader ->
        val image = reader.acquireLatestImage() ?: return@OnImageAvailableListener
        saveImage(image)
        image.close()
    }
    
    private fun saveImage(image: android.media.Image) {
        backgroundHandler.post {
            val buffer = image.planes[0].buffer
            val bytes = ByteArray(buffer.remaining())
            buffer.get(bytes)
            
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val filename = "IMG_${timestamp}.jpg"
            
            val contentValues = android.content.ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DCIM}/Camera")
                }
            }
            
            try {
                val uri = context.contentResolver.insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    contentValues
                )
                uri?.let {
                    context.contentResolver.openOutputStream(it)?.use { outputStream ->
                        outputStream.write(bytes)
                    }
                    onPhotoCaptured?.invoke(File(filename))
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error saving image", e)
            }
        }
    }
    
    fun close() {
        imageReader?.close()
        imageReader = null
    }
    
    companion object {
        private const val TAG = "CaptureController"
    }
}

