package com.zml.camera2.controller

import android.graphics.Rect
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.MeteringRectangle
import android.util.Size

/**
 * 对焦控制器
 */
class FocusController {
    
    enum class FocusMode {
        AUTO, CONTINUOUS, MANUAL
    }
    
    var focusMode = FocusMode.CONTINUOUS
        private set
    
    private var sensorArraySize: Size? = null
    
    fun setSensorArraySize(size: Size?) {
        sensorArraySize = size
    }
    
    fun setFocusMode(mode: FocusMode) {
        focusMode = mode
    }
    
    /**
     * 应用对焦设置到CaptureRequest.Builder
     */
    fun applyToRequest(builder: CaptureRequest.Builder) {
        when (focusMode) {
            FocusMode.AUTO -> {
                builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO)
            }
            FocusMode.CONTINUOUS -> {
                builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            }
            FocusMode.MANUAL -> {
                // Manual focus handled by touch focus
            }
        }
    }
    
    /**
     * 触摸对焦
     */
    fun touchFocus(
        builder: CaptureRequest.Builder,
        x: Float,
        y: Float,
        previewWidth: Int,
        previewHeight: Int
    ) {
        val focusArea = sensorArraySize ?: return
        
        val normalizedX = x / previewWidth
        val normalizedY = y / previewHeight
        
        val mappedX = (normalizedX * focusArea.width).toInt().coerceIn(0, focusArea.width)
        val mappedY = (normalizedY * focusArea.height).toInt().coerceIn(0, focusArea.height)
        
        val focusRectSize = 200
        val left = (mappedX - focusRectSize / 2).coerceAtLeast(0)
        val top = (mappedY - focusRectSize / 2).coerceAtLeast(0)
        val right = (left + focusRectSize).coerceAtMost(focusArea.width)
        val bottom = (top + focusRectSize).coerceAtMost(focusArea.height)
        
        val meteringRect = MeteringRectangle(Rect(left, top, right, bottom), 1000)
        
        builder.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_CANCEL)
        builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO)
        builder.set(CaptureRequest.CONTROL_AF_REGIONS, arrayOf(meteringRect))
        builder.set(CaptureRequest.CONTROL_AE_REGIONS, arrayOf(meteringRect))
        builder.set(CaptureRequest.CONTROL_AWB_REGIONS, arrayOf(meteringRect))
        builder.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_START)
    }
}

