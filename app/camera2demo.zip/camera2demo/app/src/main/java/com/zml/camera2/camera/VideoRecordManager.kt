package com.zml.camera2.camera

import android.hardware.camera2.CameraCharacteristics
import android.media.MediaRecorder
import android.util.Log
import android.view.Surface
import java.io.File

/**
 * 录像管理器，负责处理录像相关操作
 */
class VideoRecordManager(
    private val sessionManager: CameraSessionManager,
    private val cameraController: CameraController,
    private val settings: CameraSettings,
    private val videoSaver: VideoSaver
) {
    
    private var mediaRecorder: MediaRecorder? = null
    private var videoFile: File? = null
    private var isRecording = false
    
    var onVideoRecorded: ((File) -> Unit)? = null
    
    fun startRecording(previewSurface: Surface) {
        if (isRecording) return
        
        try {
            setupMediaRecorder()
            mediaRecorder?.start()
            isRecording = true
            
            val recorderSurface = mediaRecorder?.surface ?: return
            sessionManager.createRecordingSession(previewSurface, recorderSurface)
        } catch (e: Exception) {
            Log.e(TAG, "Error starting recording", e)
            releaseMediaRecorder()
        }
    }
    
    fun stopRecording() {
        if (!isRecording) return
        
        isRecording = false
        releaseMediaRecorder()
        videoFile?.let { onVideoRecorded?.invoke(it) }
    }
    
    private fun setupMediaRecorder() {
        releaseMediaRecorder()
        
        val previewSize = cameraController.currentPreviewSize ?: return
        videoFile = videoSaver.createVideoFile()
        
        mediaRecorder = MediaRecorder().apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setOutputFile(videoFile?.absolutePath)
            setVideoEncodingBitRate(10000000)
            setVideoFrameRate(30)
            setVideoSize(previewSize.width, previewSize.height)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setOrientationHint(getJpegOrientation())
            try {
                prepare()
            } catch (e: Exception) {
                Log.e(TAG, "Error preparing MediaRecorder", e)
            }
        }
    }
    
    private fun releaseMediaRecorder() {
        try {
            if (isRecording) {
                mediaRecorder?.stop()
                isRecording = false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping MediaRecorder", e)
        }
        
        mediaRecorder?.reset()
        mediaRecorder?.release()
        mediaRecorder = null
        
        // Save video to MediaStore
        videoFile?.let { file ->
            if (file.exists()) {
                videoSaver.saveVideoToMediaStore(file) { savedFile ->
                    file.delete()
                    videoFile = savedFile
                }
            }
        }
        
        // Recreate preview session
        // Note: This should be handled by the caller
    }
    
    private fun getJpegOrientation(): Int {
        val characteristics = cameraController.cameraCharacteristics ?: return 0
        val sensorOrientation = characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 0
        val facing = characteristics.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
        
        // Simplified orientation calculation
        return if (facing) (360 - sensorOrientation) % 360 else sensorOrientation
    }
    
    fun getRecorderSurface(): Surface? = mediaRecorder?.surface
    
    fun isCurrentlyRecording(): Boolean = isRecording
    
    companion object {
        private const val TAG = "VideoRecordManager"
    }
}

