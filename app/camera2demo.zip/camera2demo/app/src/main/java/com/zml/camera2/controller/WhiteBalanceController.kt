package com.zml.camera2.controller

import android.hardware.camera2.CaptureRequest

/**
 * 白平衡控制器
 */
class WhiteBalanceController {
    
    enum class WhiteBalanceMode {
        AUTO, MANUAL
    }
    
    var whiteBalanceMode = WhiteBalanceMode.AUTO
        private set
    
    var manualWhiteBalance = 0
        private set
    
    fun setWhiteBalanceMode(mode: WhiteBalanceMode) {
        whiteBalanceMode = mode
    }
    
    fun setManualWhiteBalance(wb: Int) {
        manualWhiteBalance = wb
    }
    
    /**
     * 应用白平衡设置到CaptureRequest.Builder
     */
    fun applyToRequest(builder: CaptureRequest.Builder) {
        if (whiteBalanceMode == WhiteBalanceMode.MANUAL) {
            builder.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_OFF)
            builder.set(CaptureRequest.COLOR_CORRECTION_MODE, CaptureRequest.COLOR_CORRECTION_MODE_TRANSFORM_MATRIX)
            // Manual white balance setting would go here
        } else {
            builder.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
        }
    }
}

