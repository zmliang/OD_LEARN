package com.zml.camera2.camera

import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraDevice
import android.media.ImageReader
import android.view.Surface
import java.io.File

/**
 * 相机管理器，统一管理所有相机相关操作
 * 职责：协调各个子管理器，提供统一的接口
 */
class CameraManager(private val context: Context) {
    
    private val settings = CameraSettings()
    private val cameraController = CameraController(context)
    private val sessionManager = CameraSessionManager(cameraController, settings)
    private val imageCaptureManager = ImageCaptureManager(sessionManager, cameraController, settings, context)
    private val imageSaver = ImageSaver(context)
    private val videoSaver = VideoSaver(context)
    private val videoRecordManager = VideoRecordManager(sessionManager, cameraController, settings, videoSaver)
    
    private var previewReader: ImageReader? = null
    private var textureId: Int? = null
    
    // Callbacks
    var onPreviewReady: ((SurfaceTexture) -> Unit)? = null
    var onPhotoCaptured: ((File) -> Unit)? = null
    var onVideoRecorded: ((File) -> Unit)? = null
    
    init {
        setupCallbacks()
    }
    
    private fun setupCallbacks() {
        cameraController.onCameraOpened = { device ->
            // Camera opened, session will be created by caller
        }
        
        cameraController.onCameraDisconnected = {
            // Handle disconnection
        }
        
        cameraController.onCameraError = { error ->
            // Handle error
        }
        
        sessionManager.onSessionConfigured = { session ->
            // Session configured
        }
        
        sessionManager.onImageAvailable = ImageReader.OnImageAvailableListener { reader ->
            val image = reader.acquireLatestImage() ?: return@OnImageAvailableListener
            imageSaver.saveImage(image) { file ->
                onPhotoCaptured?.invoke(file)
            }
            image.close()
        }
        
        imageCaptureManager.onPhotoCaptured = { filename ->
            // Photo captured, handled by imageSaver callback
        }
        
        videoRecordManager.onVideoRecorded = { file ->
            onVideoRecorded?.invoke(file)
        }
    }
    
    fun getSettings(): CameraSettings = settings
    
    fun openCamera(isFront: Boolean = false) {
        cameraController.openCamera(isFront, settings.aspectRatio)
    }
    
    fun createPreviewSession() {
        val textureId = this.textureId
        if (textureId == null) {
            // Wait for texture ID
            return
        }
        
        val surfaceTexture = createSurfaceTexture(textureId)
        val surface = Surface(surfaceTexture)
        onPreviewReady?.invoke(surfaceTexture)
        
        sessionManager.createPreviewSession(surface)
    }
    
    fun setTextureId(id: Int) {
        textureId = id
    }
    
    fun getTextureId(): Int? = textureId
    
    fun createSurfaceTexture(textureId: Int): SurfaceTexture {
        val surfaceTexture = SurfaceTexture(textureId)
        val previewSize = cameraController.currentPreviewSize
        surfaceTexture.setDefaultBufferSize(
            previewSize?.width ?: 1920,
            previewSize?.height ?: 1080
        )
        return surfaceTexture
    }
    
    fun takePicture(shutterSound: Boolean = true) {
        imageCaptureManager.takePicture(shutterSound)
    }
    
    fun touchFocus(x: Float, y: Float, width: Int, height: Int) {
        sessionManager.touchFocus(x, y, width, height)
    }
    
    fun setZoom(zoom: Float) {
        settings.zoom = zoom.coerceIn(1.0f, cameraController.maxZoom)
        sessionManager.updatePreviewRequest()
    }
    
    fun getMaxZoom(): Float = cameraController.maxZoom
    
    fun switchCamera() {
        closeCamera()
        cameraController.isFrontCamera = !cameraController.isFrontCamera
        openCamera(cameraController.isFrontCamera)
    }
    
    fun startRecording(previewSurface: Surface) {
        videoRecordManager.startRecording(previewSurface)
    }
    
    fun stopRecording() {
        videoRecordManager.stopRecording()
        // Recreate preview session after recording
        createPreviewSession()
    }
    
    fun isRecording(): Boolean = videoRecordManager.isCurrentlyRecording()
    
    fun updateSettings() {
        sessionManager.updatePreviewRequest()
    }
    
    fun closeCamera() {
        sessionManager.closeSession()
        cameraController.closeCamera()
        previewReader?.close()
        previewReader = null
    }
    
    fun stopBackgroundThread() {
        cameraController.stopBackgroundThread()
    }
    
    
    fun setupPreviewReaderForFaceDetection() {
        val previewSize = cameraController.currentPreviewSize ?: return
        previewReader = ImageReader.newInstance(640, 480, android.graphics.ImageFormat.YUV_420_888, 2)
    }
    
    fun getPreviewReader(): ImageReader? = previewReader
}

