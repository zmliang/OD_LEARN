package com.zml.camera2.preview

import android.graphics.SurfaceTexture
import android.view.View
import com.zml.camera2.Filter
import com.zml.camera2.FaceRect

/**
 * 预览策略接口，支持不同的预览视图实现
 */
interface PreviewStrategy {
    /**
     * 获取预览视图
     */
    fun getPreviewView(): View
    
    /**
     * 设置SurfaceTexture监听器
     */
    fun setSurfaceTextureListener(listener: SurfaceTextureListener)
    
    /**
     * 更新纹理图像
     */
    fun updateTexImage()
    
    /**
     * 设置相机纹理ID（用于GLSurfaceView）
     */
    fun setCameraTexture(textureId: Int)
    
    /**
     * 设置滤镜
     */
    fun setFilter(filter: Filter)
    
    /**
     * 设置人脸框
     */
    fun setFaces(faces: List<FaceRect>)
    
    /**
     * 设置网格线显示
     */
    fun setGridLines(show: Boolean)
    
    /**
     * 设置缩放
     */
    fun setZoom(zoom: Float)
    
    /**
     * 设置宽高比
     */
    fun setAspectRatio(width: Int, height: Int)
    
    /**
     * SurfaceTexture 监听器
     */
    interface SurfaceTextureListener {
        fun onSurfaceTextureAvailable(texture: SurfaceTexture, width: Int, height: Int)
        fun onSurfaceTextureSizeChanged(texture: SurfaceTexture, width: Int, height: Int)
        fun onSurfaceTextureDestroyed(texture: SurfaceTexture): Boolean
        fun onSurfaceTextureUpdated(texture: SurfaceTexture)
    }
}

