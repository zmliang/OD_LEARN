package com.zml.camera2.preview

import android.content.Context
import android.graphics.SurfaceTexture
import android.util.AttributeSet
import android.view.Surface
import android.view.TextureView
import android.view.View

/**
 * 基于TextureView的预览实现
 */
class TextureViewPreviewView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : IPreviewView, TextureView.SurfaceTextureListener {
    
    private val textureView: TextureView
    
    private var surfaceTextureListener: IPreviewView.SurfaceTextureListener? = null
    private var renderCallback: IPreviewView.RenderCallback? = null
    private var currentSurfaceTexture: SurfaceTexture? = null
    
    init {
        textureView = TextureView(context, attrs)
        textureView.surfaceTextureListener = this
    }
    
    override fun getView(): View = textureView

    
    override fun setSurfaceTextureListener(listener: IPreviewView.SurfaceTextureListener) {
        this.surfaceTextureListener = listener
        currentSurfaceTexture?.let {
            // TextureView没有textureId的概念，使用0作为标识
            listener.onSurfaceTextureAvailable(0)
        }
    }
    
    override fun updateTexImage() {
        // TextureView会自动更新，不需要手动调用
        renderCallback?.onFrameAvailable()
    }
    
    override fun getSurfaceTexture(): SurfaceTexture? = currentSurfaceTexture
    
    override fun setRenderCallback(callback: IPreviewView.RenderCallback?) {
        this.renderCallback = callback
    }
    
    // TextureView.SurfaceTextureListener implementation
    override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
        currentSurfaceTexture = surface
        // TextureView直接使用SurfaceTexture，不需要textureId
        surfaceTextureListener?.onSurfaceTextureAvailable(0)
    }
    
    override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {
        // 处理尺寸变化
    }
    
    override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
        currentSurfaceTexture = null
        return true
    }
    
    override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {
        renderCallback?.onFrameAvailable()
    }
}

