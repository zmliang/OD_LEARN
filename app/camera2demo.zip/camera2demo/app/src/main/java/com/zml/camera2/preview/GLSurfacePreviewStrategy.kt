package com.zml.camera2.preview

import android.content.Context
import android.graphics.SurfaceTexture
import android.opengl.GLSurfaceView
import android.view.View
import com.zml.camera2.CameraGLSurfaceView
import com.zml.camera2.CameraRenderer
import com.zml.camera2.Filter
import com.zml.camera2.FaceRect

/**
 * 基于 GLSurfaceView 的预览策略实现
 */
class GLSurfacePreviewStrategy(context: Context) : PreviewStrategy {
    
    private val glSurfaceView: CameraGLSurfaceView = CameraGLSurfaceView(context)
    private var listener: PreviewStrategy.SurfaceTextureListener? = null
    
    init {
        glSurfaceView.setEGLContextClientVersion(2)
        val renderer = CameraRenderer()
        glSurfaceView.setRenderer(renderer)
        glSurfaceView.renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
    }
    
    override fun getPreviewView(): View = glSurfaceView
    
    override fun setSurfaceTextureListener(listener: PreviewStrategy.SurfaceTextureListener) {
        this.listener = listener
        // GLSurfaceView 的 SurfaceTexture 在渲染器中创建
        // 这里可以通过回调通知
    }
    
    override fun updateTexImage() {
        glSurfaceView.queueEvent {
            glSurfaceView.updateTexImage()
        }
        glSurfaceView.requestRender()
    }
    
    override fun setCameraTexture(textureId: Int) {
        glSurfaceView.setCameraTexture(textureId)
    }
    
    override fun setFilter(filter: Filter) {
        glSurfaceView.setFilter(filter)
    }
    
    override fun setFaces(faces: List<FaceRect>) {
        glSurfaceView.setFaces(faces)
    }
    
    override fun setGridLines(show: Boolean) {
        glSurfaceView.setGridLines(show)
    }
    
    override fun setZoom(zoom: Float) {
        glSurfaceView.setZoom(zoom)
    }
    
    override fun setAspectRatio(width: Int, height: Int) {
        glSurfaceView.setAspectRatio(width, height)
    }
    
    fun getRenderer(): CameraRenderer? {
        return glSurfaceView.renderer
    }
}

