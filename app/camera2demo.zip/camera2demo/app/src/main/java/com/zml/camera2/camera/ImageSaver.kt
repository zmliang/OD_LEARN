package com.zml.camera2.camera

import android.content.Context
import android.media.Image
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * 图片保存器，负责保存图片到媒体库
 */
class ImageSaver(private val context: Context) {
    
    fun saveImage(image: Image, onSaved: (File) -> Unit) {
        try {
            val buffer = image.planes[0].buffer
            val bytes = ByteArray(buffer.remaining())
            buffer.get(bytes)
            
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val filename = "IMG_${timestamp}.jpg"
            
            val contentValues = android.content.ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DCIM}/Camera")
                }
            }
            
            val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
            uri?.let {
                context.contentResolver.openOutputStream(it)?.use { outputStream ->
                    outputStream.write(bytes)
                }
                onSaved(File(filename))
            } ?: run {
                Log.e(TAG, "Failed to create MediaStore entry")
                onSaved(File(filename))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error saving image", e)
            val filename = "IMG_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())}.jpg"
            onSaved(File(filename))
        }
    }
    
    companion object {
        private const val TAG = "ImageSaver"
    }
}

