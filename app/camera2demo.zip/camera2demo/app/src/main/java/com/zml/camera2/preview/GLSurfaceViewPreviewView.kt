package com.zml.camera2.preview

import android.content.Context
import android.graphics.SurfaceTexture
import android.util.AttributeSet
import android.view.Surface
import android.view.View
import com.zml.camera2.CameraGLSurfaceView
import com.zml.camera2.FaceRect
import com.zml.camera2.Filter

/**
 * 基于GLSurfaceView的预览实现
 */
class GLSurfaceViewPreviewView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : IPreviewView {
    
    private val glSurfaceView: CameraGLSurfaceView
    
    private var surfaceTextureListener: IPreviewView.SurfaceTextureListener? = null
    private var renderCallback: IPreviewView.RenderCallback? = null
    private var textureId: Int? = null
    
    init {
        glSurfaceView = CameraGLSurfaceView(context, attrs)
        setupGLSurfaceView()
    }
    
    private fun setupGLSurfaceView() {
        // GLSurfaceView初始化在CameraGLSurfaceView内部完成
        glSurfaceView.queueEvent {
            val textures = IntArray(1)
            android.opengl.GLES20.glGenTextures(1, textures, 0)
            textureId = textures[0]
            
            // 配置纹理
            android.opengl.GLES20.glBindTexture(
                android.opengl.GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                textureId!!
            )
            android.opengl.GLES20.glTexParameteri(
                android.opengl.GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                android.opengl.GLES20.GL_TEXTURE_MIN_FILTER,
                android.opengl.GLES20.GL_LINEAR
            )
            android.opengl.GLES20.glTexParameteri(
                android.opengl.GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                android.opengl.GLES20.GL_TEXTURE_MAG_FILTER,
                android.opengl.GLES20.GL_LINEAR
            )
            android.opengl.GLES20.glTexParameteri(
                android.opengl.GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                android.opengl.GLES20.GL_TEXTURE_WRAP_S,
                android.opengl.GLES20.GL_CLAMP_TO_EDGE
            )
            android.opengl.GLES20.glTexParameteri(
                android.opengl.GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                android.opengl.GLES20.GL_TEXTURE_WRAP_T,
                android.opengl.GLES20.GL_CLAMP_TO_EDGE
            )
            
            textureId?.let { id ->
                glSurfaceView.post {
                    surfaceTextureListener?.onSurfaceTextureAvailable(id)
                }
            }
        }
    }
    
    override fun getView(): View = glSurfaceView
    
    override fun setSurfaceTextureListener(listener: IPreviewView.SurfaceTextureListener) {
        this.surfaceTextureListener = listener
        textureId?.let { listener.onSurfaceTextureAvailable(it) }
    }
    
    override fun updateTexImage() {
        glSurfaceView.updateTexImage()
    }
    
    override fun getSurfaceTexture(): SurfaceTexture? {
        // GLSurfaceView的SurfaceTexture需要通过CameraRenderer获取
        // 这里返回null，实际通过onSurfaceTextureAvailable回调传递textureId来创建
        return null
    }
    
    override fun setRenderCallback(callback: IPreviewView.RenderCallback?) {
        this.renderCallback = callback
    }

    
    fun getTextureId(): Int? = textureId
    
    fun setCameraTexture(textureId: Int) {
        glSurfaceView.setCameraTexture(textureId)
    }
    
    fun setFilter(filter: Filter) {
        glSurfaceView.setFilter(filter)
    }
    
    fun setFaces(faces: List<FaceRect>) {
        glSurfaceView.setFaces(faces)
    }
    
    fun setGridLines(show: Boolean) {
        glSurfaceView.setGridLines(show)
    }
    
    fun setZoom(zoom: Float) {
        glSurfaceView.setZoom(zoom)
    }
    
    fun setAspectRatio(width: Int, height: Int) {
        glSurfaceView.setAspectRatio(width, height)
    }
}

