package com.zml.camera2.viewmodel

import android.app.Application
import android.content.Context
import android.os.Handler
import android.os.HandlerThread
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.zml.camera2.Filter
import com.zml.camera2.CameraController
import com.zml.camera2.controller.*
import com.zml.camera2.preview.IPreviewView
import com.zml.camera2.preview.PreviewViewFactory
import com.zml.camera2.preview.GLSurfaceViewPreviewView
import com.zml.camera2.settings.CameraSettings
import com.zml.camera2.settings.SettingsManager
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 相机ViewModel - 管理相机业务逻辑
 */
class CameraViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext

    private var cameraController: CameraController? = null
    private lateinit var captureController: CaptureController
    private lateinit var videoController: VideoController

    private var backgroundThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null

    private var previewView: IPreviewView? = null

    private val settingsManager = SettingsManager(context)

    // UI State
    private val _isCameraInitialized = MutableLiveData<Boolean>(false)
    val isCameraInitialized: LiveData<Boolean> = _isCameraInitialized

    private val _photoCaptured = MutableLiveData<File?>()
    val photoCaptured: LiveData<File?> = _photoCaptured

    private val _videoRecorded = MutableLiveData<File?>()
    val videoRecorded: LiveData<File?> = _videoRecorded

    private val _isRecording = MutableLiveData<Boolean>(false)
    val isRecording: LiveData<Boolean> = _isRecording

    private val _currentFlashMode = MutableLiveData<FlashController.FlashMode>()
    val currentFlashMode: LiveData<FlashController.FlashMode> = _currentFlashMode

    private val _currentFilter = MutableLiveData<Filter>(Filter.NORMAL)
    val currentFilter: LiveData<Filter> = _currentFilter

    private val inited = AtomicBoolean(false)

    // Settings
    private var currentSettings = settingsManager.loadSettings()


    fun initialize(preview: IPreviewView?) {

        if (backgroundThread == null) {
            backgroundThread = HandlerThread("CameraBackground").also { it.start() }
            backgroundHandler = Handler(backgroundThread?.looper!!)
            captureController = CaptureController(context, backgroundHandler!!)
            videoController = VideoController(context, backgroundHandler!!)
        }
        cameraController = CameraController(context,preview!!, captureController, videoController, backgroundHandler!!)
        this.previewView = preview

        setupCallbacks()

        previewView?.setSurfaceTextureListener(object : IPreviewView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(textureId: Int) {
                cameraController?.setTextureId(textureId)
                previewView?.getView()?.post {
                    if (!inited.get()){
                        inited.set(true)
                        cameraController?.openCamera()
                    }
                }
                //cameraController?.openCamera()
                _isCameraInitialized.postValue(true)
            }
        })

        // 应用保存的设置
        applySettings(currentSettings)

        // 启用/禁用人脸检测
        if (currentSettings.enableFaceDetection) {
            cameraController?.setFaceDetectionEnabled(true)
        }
    }

    private fun setupCallbacks() {
        cameraController?.setOnPhotoCaptured { file ->
            _photoCaptured.postValue(file)
        }

        cameraController?.setOnVideoRecorded { file ->
            _videoRecorded.postValue(file)
            _isRecording.postValue(false)
        }

        cameraController?.onPreviewReady = { surfaceTexture ->
            surfaceTexture?.setOnFrameAvailableListener {
                previewView?.updateTexImage()
            }
        }

        // Setup face detection callback from CameraController
        cameraController?.onFacesDetected = { faces ->
            if (currentSettings.enableFaceDetection && previewView is GLSurfaceViewPreviewView) {
                (previewView as GLSurfaceViewPreviewView).setFaces(faces)
            }
        }

        _currentFlashMode.postValue(currentSettings.flashMode)
    }

    fun getPreviewView(): IPreviewView? = previewView

    fun takePicture(countdownSeconds: Int = 0, onComplete: () -> Unit = {}) {
        if (countdownSeconds > 0) {
            // 倒计时功能应该由UI层处理
            cameraController?.takePicture(true)
        } else {
            cameraController?.takePicture(true)
        }
    }

    fun startRecording() {
        cameraController?.startRecording()
        _isRecording.postValue(true)
    }

    fun stopRecording() {
        cameraController?.stopRecording()
    }

    fun switchCamera() {
        cameraController?.switchCamera()
    }

    fun cycleFlashMode() {
        cameraController?.getFlashController()?.cycleFlashMode()
        val newMode = cameraController?.getFlashController()?.flashMode ?: FlashController.FlashMode.OFF
        _currentFlashMode.postValue(newMode)
        currentSettings.flashMode = newMode
        saveSettings()
    }

    fun setFocusMode(mode: FocusController.FocusMode) {
        cameraController?.getFocusController()?.setFocusMode(mode)
        currentSettings.focusMode = mode
        cameraController?.updatePreviewRequest()
        saveSettings()
    }

    fun setExposureMode(mode: ExposureController.ExposureMode) {
        cameraController?.getExposureController()?.setExposureMode(mode)
        currentSettings.exposureMode = mode
        cameraController?.updatePreviewRequest()
        saveSettings()
    }

    fun setWhiteBalanceMode(mode: WhiteBalanceController.WhiteBalanceMode) {
        cameraController?.getWhiteBalanceController()?.setWhiteBalanceMode(mode)
        currentSettings.whiteBalanceMode = mode
        cameraController?.updatePreviewRequest()
        saveSettings()
    }

    fun setAspectRatio(ratio: CameraSettings.AspectRatio) {
        currentSettings.aspectRatio = ratio
        cameraController?.setAspectRatio(ratio)
        saveSettings()
    }

    fun setZoom(zoom: Float) {
        cameraController?.setZoom(zoom)
        currentSettings.zoom = zoom
        previewView?.let {
            if (it is GLSurfaceViewPreviewView) {
                it.setZoom(zoom)
            }
        }
        saveSettings()
    }

    fun touchFocus(x: Float, y: Float, width: Int, height: Int) {
        cameraController?.touchFocus(x, y, width, height)
    }

    fun setFilter(filter: Filter) {
        _currentFilter.postValue(filter)
        previewView?.let {
            if (it is GLSurfaceViewPreviewView) {
                it.setFilter(filter)
            }
        }
    }

    fun cycleFilter() {
        val current = _currentFilter.value ?: Filter.NORMAL
        val next = Filter.values()[(current.ordinal + 1) % Filter.values().size]
        setFilter(next)
    }

    fun setGridLines(show: Boolean) {
        currentSettings.showGridLines = show
        previewView?.let {
            if (it is GLSurfaceViewPreviewView) {
                it.setGridLines(show)
            }
        }
        saveSettings()
    }

    fun setFaceDetection(enable: Boolean) {
        currentSettings.enableFaceDetection = enable
        cameraController?.setFaceDetectionEnabled(enable)
        saveSettings()
    }

    fun isFaceDetectionSupported(): Boolean {
        return cameraController?.isFaceDetectionSupported() ?: false
    }

    fun applySettings(settings: CameraSettings) {
        currentSettings = settings
        cameraController?.applySettings(settings)
        _currentFlashMode.postValue(settings.flashMode)

        previewView?.let {
            if (it is GLSurfaceViewPreviewView) {
                it.setFilter(_currentFilter.value ?: Filter.NORMAL)
                it.setGridLines(settings.showGridLines)
                it.setZoom(settings.zoom)
            }
        }
    }
    
    private fun saveSettings() {
        settingsManager.saveSettings(currentSettings)
    }
    
    fun getCurrentSettings(): CameraSettings = currentSettings
    
    fun getMaxZoom(): Float = cameraController?.getMaxZoom() ?: 1.0f
    
    fun getCurrentZoom(): Float = cameraController?.getCurrentZoom() ?: 1.0f
    
    override fun onCleared() {
        super.onCleared()
        cameraController?.closeCamera()
        cameraController?.stopBackgroundThread()
        previewView = null
    }
}

