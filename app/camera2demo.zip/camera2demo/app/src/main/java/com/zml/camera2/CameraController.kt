package com.zml.camera2

import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.hardware.camera2.params.Face
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.util.Size
import android.view.Surface
import androidx.core.content.ContextCompat
import com.zml.camera2.controller.*
import com.zml.camera2.preview.IPreviewView
import com.zml.camera2.settings.CameraSettings
import java.io.File

/**
 * 相机控制器 - 负责相机的基本操作和会话管理
 */
class CameraController(private val context: Context, private val previewView: IPreviewView,
    val captureController: CaptureController,
    val videoController: VideoController,
    val backgroundHandler: Handler) {
    
    private val cameraManager: CameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var previewRequestBuilder: CaptureRequest.Builder? = null
    

    
    private var cameraId: String? = null
    private var isFrontCamera = false
    private var previewSize: Size? = null
    private var sensorArraySize: Size? = null
    
    // Controllers
    private val flashController = FlashController()
    private val focusController = FocusController()
    private val exposureController = ExposureController()
    private val whiteBalanceController = WhiteBalanceController()
    private val zoomController = ZoomController()
    private val faceDetector = FaceDetector()

    
    // Face detection support
    private var isFaceDetectionSupported = false
    private var faceDetectionEnabled = false
    
    // Callbacks
    var onPreviewReady: ((SurfaceTexture?) -> Unit)? = null
    var onFacesDetected: ((List<FaceRect>) -> Unit)? = null
    
    private var textureId: Int? = null

//    init {
//        //startBackgroundThread()
//    }
//
//    fun startBackgroundThread() {
//        if (backgroundThread == null) {
//            backgroundThread = HandlerThread("CameraBackground").also { it.start() }
//            backgroundHandler = Handler(backgroundThread?.looper!!)
//            //captureController = CaptureController(context, backgroundHandler!!)
//            //videoController = VideoController(context, backgroundHandler!!)
//        }
//    }
    
    fun stopBackgroundThread() {
//        backgroundThread?.quitSafely()
//        try {
//            backgroundThread?.join()
//            backgroundThread = null
//            backgroundHandler = null
//        } catch (e: InterruptedException) {
//            e.printStackTrace()
//        }
    }
    
    fun openCamera() {
        //startBackgroundThread()
        
        try {
            val cameraList = cameraManager.cameraIdList
            cameraId = if (isFrontCamera) {
                cameraList.find { 
                    cameraManager.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == 
                        CameraCharacteristics.LENS_FACING_FRONT
                } ?: cameraList[0]
            } else {
                cameraList.find { 
                    cameraManager.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == 
                        CameraCharacteristics.LENS_FACING_BACK
                } ?: cameraList[0]
            }
            
            cameraId?.let { id ->
                val characteristics = cameraManager.getCameraCharacteristics(id)
                val map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
                
                sensorArraySize = characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)?.let {
                    Size(it.width(), it.height())
                }
                
                // Check face detection support
                isFaceDetectionSupported = faceDetector.isFaceDetectionSupported(characteristics)
                if (isFaceDetectionSupported) {
                    faceDetector.setSensorArraySize(sensorArraySize)
                }
                
                val zoomRange = characteristics.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM)
                zoomController.setMaxZoom(zoomRange ?: 1.0f)
                zoomController.setSensorArraySize(sensorArraySize)
                focusController.setSensorArraySize(sensorArraySize)
                
                val displaySize = context.resources.displayMetrics
                val screenAspect = displaySize.widthPixels.toFloat() / displaySize.heightPixels.toFloat()
                
                // 根据aspect ratio选择预览尺寸
                val targetAspect = when (getCurrentAspectRatio()) {
                    CameraSettings.AspectRatio.RATIO_16_9 -> 16f / 9f
                    CameraSettings.AspectRatio.RATIO_4_3 -> 4f / 3f
                    CameraSettings.AspectRatio.RATIO_1_1 -> 1f
                }
                
                val sizes = map.getOutputSizes(android.graphics.ImageFormat.JPEG)
                previewSize = sizes.sortedByDescending { it.width * it.height }
                    .firstOrNull { 
                        val aspect = it.width.toFloat() / it.height.toFloat()
                        kotlin.math.abs(aspect - targetAspect) < 0.1f
                    } ?: sizes[0]
                
                previewSize?.let { size ->
                    captureController.initialize(size)
                    videoController.initialize(size, getJpegOrientation())
                    if (isFaceDetectionSupported) {
                        faceDetector.setPreviewSize(size)
                    }
                }
                
                if (ContextCompat.checkSelfPermission(
                        context,
                        android.Manifest.permission.CAMERA
                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                ) {
                    cameraManager.openCamera(id, stateCallback, backgroundHandler)
                }
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "Camera permission not granted", e)
        } catch (e: Exception) {
            Log.e(TAG, "Error opening camera", e)
        }
    }
    
    private val stateCallback = object : CameraDevice.StateCallback() {
        override fun onOpened(camera: CameraDevice) {
            cameraDevice = camera
            createPreviewSession()
        }
        
        override fun onDisconnected(camera: CameraDevice) {
            camera.close()
            cameraDevice = null
        }
        
        override fun onError(camera: CameraDevice, error: Int) {
            camera.close()
            cameraDevice = null
        }
    }
    
    private fun createPreviewSession() {
        try {
            cameraDevice?.let { device ->
                val textureId = getTextureId()
                if (textureId == null) {
                    backgroundHandler?.postDelayed({
                        createPreviewSession()
                    }, 100)
                    return
                }
                val surfaceTexture = previewView.getSurfaceTexture()//createSurfaceTexture(textureId)
                previewSize?.let { size ->
                    surfaceTexture?.setDefaultBufferSize(size.width, size.height)
                }
                val surface = Surface(surfaceTexture)
                onPreviewReady?.invoke(surfaceTexture)
                
                previewRequestBuilder = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                    addTarget(surface)
                    applyControllers(this)
                }
                
                val surfaces = mutableListOf(surface, captureController.getImageReaderSurface()!!)
                device.createCaptureSession(
                    surfaces,
                    object : CameraCaptureSession.StateCallback() {
                        override fun onConfigured(session: CameraCaptureSession) {
                            captureSession = session
                            updatePreviewRequest()
                        }
                        
                        override fun onConfigureFailed(session: CameraCaptureSession) {
                            Log.e(TAG, "Capture session configuration failed")
                        }
                    },
                    backgroundHandler
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error creating preview session", e)
        }
    }
    
    private fun createSurfaceTexture(textureId: Int): SurfaceTexture {
        val surfaceTexture = SurfaceTexture(textureId)
        previewSize?.let { size ->
            surfaceTexture.setDefaultBufferSize(size.width, size.height)
        }
        return surfaceTexture
    }
    
    private fun applyControllers(builder: CaptureRequest.Builder) {
        // 先设置默认值
        builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
        builder.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
        
        // ExposureController先应用（设置CONTROL_AE_MODE）
        exposureController.applyToRequest(builder)
        
        // FlashController设置FLASH_MODE
        // 注意：FlashController的AUTO模式会设置CONTROL_AE_MODE_ON_AUTO_FLASH
        // 但只有在ExposureMode是AUTO时才生效（手动曝光模式优先级更高）
        if (exposureController.exposureMode == ExposureController.ExposureMode.AUTO) {
            flashController.applyToRequest(builder)
        } else {
            // 手动曝光模式下，只设置FLASH_MODE，不设置CONTROL_AE_MODE
            when (flashController.flashMode) {
                FlashController.FlashMode.OFF -> {
                    builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_OFF)
                }
                FlashController.FlashMode.ON -> {
                    builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_SINGLE)
                }
                FlashController.FlashMode.AUTO -> {
                    // 手动曝光模式下，AUTO闪光灯不可用，使用OFF
                    builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_OFF)
                }
            }
        }
        
        // 其他Controller
        focusController.applyToRequest(builder)
        whiteBalanceController.applyToRequest(builder)
        zoomController.applyToRequest(builder)
        
        // Face detection
        if (isFaceDetectionSupported && faceDetectionEnabled) {
            faceDetector.enableFaceDetection(builder)
        }
    }
    
    fun updatePreviewRequest() {
        previewRequestBuilder?.let { builder ->
            applyControllers(builder)
            val callback = if (isFaceDetectionSupported && faceDetectionEnabled) {
                object : CameraCaptureSession.CaptureCallback() {
                    override fun onCaptureCompleted(
                        session: CameraCaptureSession,
                        request: CaptureRequest,
                        result: TotalCaptureResult
                    ) {
                        val faces = faceDetector.processFaceDetectionResult(result)
                        if (faces.isNotEmpty()) {
                            onFacesDetected?.invoke(faces)
                        }
                    }
                }
            } else {
                null
            }
            captureSession?.setRepeatingRequest(builder.build(), callback, backgroundHandler)
        }
    }
    
    // Public methods for camera operations
    fun switchCamera() {
        closeCamera()
        isFrontCamera = !isFrontCamera
        openCamera()
    }
    
    fun takePicture(shutterSound: Boolean = true) {
        previewRequestBuilder?.let { builder ->
            builder.addTarget(captureController.getImageReaderSurface()!!)
            applyControllers(builder)
            captureSession?.let { session ->
                captureController.takePicture(builder, session, shutterSound)
            }
        }
    }
    
    fun startRecording() {
        videoController.startRecording()?.let { surface ->
            // Switch to recording session
            cameraDevice?.let { device ->
                captureSession?.close()
                captureSession = null
                
                val textureId = getTextureId() ?: return
                val surfaceTexture = createSurfaceTexture(textureId)
                val previewSurface = Surface(surfaceTexture)
                onPreviewReady?.invoke(surfaceTexture)
                
                previewRequestBuilder = device.createCaptureRequest(CameraDevice.TEMPLATE_RECORD).apply {
                    addTarget(previewSurface)
                    addTarget(surface)
                    applyControllers(this)
                }
                
                device.createCaptureSession(
                    listOf(previewSurface, surface),
                    object : CameraCaptureSession.StateCallback() {
                        override fun onConfigured(session: CameraCaptureSession) {
                            captureSession = session
                            updatePreviewRequest()
                        }
                        
                        override fun onConfigureFailed(session: CameraCaptureSession) {
                            Log.e(TAG, "Recording session configuration failed")
                        }
                    },
                    backgroundHandler
                )
            }
        }
    }
    
    fun stopRecording() {
        videoController.stopRecording()
        // Recreate preview session
        createPreviewSession()
    }
    
    fun touchFocus(x: Float, y: Float, width: Int, height: Int) {
        previewRequestBuilder?.let { builder ->
            focusController.touchFocus(builder, x, y, width, height)
            captureSession?.capture(builder.build(), object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(
                    session: CameraCaptureSession,
                    request: CaptureRequest,
                    result: TotalCaptureResult
                ) {
                    updatePreviewRequest()
                }
            }, backgroundHandler)
        }
    }
    
    fun setZoom(zoom: Float) {
        zoomController.setZoom(zoom)
        updatePreviewRequest()
    }
    
    fun getMaxZoom(): Float = zoomController.getMaxZoom()
    
    fun getCurrentZoom(): Float = zoomController.getCurrentZoom()
    
    fun getPreviewSize(): Size? = previewSize
    
    // Settings
    fun applySettings(settings: CameraSettings) {
        flashController.setFlashMode(settings.flashMode)
        focusController.setFocusMode(settings.focusMode)
        exposureController.setExposureMode(settings.exposureMode)
        exposureController.setManualExposure(settings.manualExposure)
        whiteBalanceController.setWhiteBalanceMode(settings.whiteBalanceMode)
        whiteBalanceController.setManualWhiteBalance(settings.manualWhiteBalance)
        zoomController.setZoom(settings.zoom)
        updatePreviewRequest()
    }
    
    fun getSettings(): CameraSettings {
        return CameraSettings(
            flashMode = flashController.flashMode,
            focusMode = focusController.focusMode,
            exposureMode = exposureController.exposureMode,
            manualExposure = exposureController.manualExposure,
            whiteBalanceMode = whiteBalanceController.whiteBalanceMode,
            manualWhiteBalance = whiteBalanceController.manualWhiteBalance,
            aspectRatio = getCurrentAspectRatio(),
            zoom = zoomController.getCurrentZoom(),
            showGridLines = false, // 这个应该从UI层管理
            enableFaceDetection = false // 这个应该从UI层管理
        )
    }
    
    private var currentAspectRatio = CameraSettings.AspectRatio.RATIO_16_9
    
    fun setAspectRatio(ratio: CameraSettings.AspectRatio) {
        currentAspectRatio = ratio
        closeCamera()
        openCamera()
    }
    
    fun getCurrentAspectRatio(): CameraSettings.AspectRatio = currentAspectRatio
    
    // Controller getters
    fun getFlashController(): FlashController = flashController
    fun getFocusController(): FocusController = focusController
    fun getExposureController(): ExposureController = exposureController
    fun getWhiteBalanceController(): WhiteBalanceController = whiteBalanceController
    fun getZoomController(): ZoomController = zoomController
    
    fun getFaceDetector(): FaceDetector = faceDetector
    
    fun isFaceDetectionSupported(): Boolean = isFaceDetectionSupported
    
    fun setFaceDetectionEnabled(enabled: Boolean) {
        faceDetectionEnabled = enabled && isFaceDetectionSupported
        updatePreviewRequest()
    }
    
    fun isFaceDetectionEnabled(): Boolean = faceDetectionEnabled

    
    fun getTextureId(): Int? = textureId
    
    fun setTextureId(id: Int) {
        textureId = id
    }
    
    fun closeCamera() {
        captureSession?.close()
        captureSession = null
        
        cameraDevice?.close()
        cameraDevice = null
        
        captureController.close()
        videoController.close()
    }
    
    private fun getJpegOrientation(): Int {
        val rotation = (context as? android.app.Activity)?.windowManager?.defaultDisplay?.rotation ?: 0
        val characteristics = cameraId?.let { cameraManager.getCameraCharacteristics(it) }
        val sensorOrientation = characteristics?.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 0
        val facing = characteristics?.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
        
        return when (rotation) {
            Surface.ROTATION_0 -> if (facing) (360 - sensorOrientation) % 360 else sensorOrientation
            Surface.ROTATION_90 -> if (facing) (270 - sensorOrientation + 360) % 360 else (sensorOrientation + 90) % 360
            Surface.ROTATION_180 -> if (facing) (180 - sensorOrientation + 360) % 360 else (sensorOrientation + 180) % 360
            Surface.ROTATION_270 -> if (facing) (90 - sensorOrientation + 360) % 360 else (sensorOrientation + 270) % 360
            else -> sensorOrientation
        }
    }
    
    // Callbacks setup
    fun setOnPhotoCaptured(callback: (File) -> Unit) {
        captureController.onPhotoCaptured = callback
    }
    
    fun setOnVideoRecorded(callback: (File) -> Unit) {
        videoController.onVideoRecorded = callback
    }
    
    companion object {
        private const val TAG = "CameraController"
    }
}

