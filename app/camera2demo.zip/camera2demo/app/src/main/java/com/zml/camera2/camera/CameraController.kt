package com.zml.camera2.camera

import android.content.Context
import android.hardware.camera2.*
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.util.Size
import androidx.core.content.ContextCompat

/**
 * 相机控制器，负责相机设备的打开、关闭等基础操作
 */
class CameraController(private val context: Context) {
    
    private val cameraManager: android.hardware.camera2.CameraManager =
        context.getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
    
    private var cameraDevice: CameraDevice? = null
    private var cameraId: String? = null
    var isFrontCamera = false
    
    private var backgroundThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null
    
    private var previewSize: Size? = null
    var maxZoom: Float = 1.0f
        private set
    
    val cameraCharacteristics: CameraCharacteristics?
        get() = cameraId?.let { cameraManager.getCameraCharacteristics(it) }
    
    val currentCameraId: String?
        get() = cameraId
    
    val currentPreviewSize: Size?
        get() = previewSize
    
    var onCameraOpened: ((CameraDevice) -> Unit)? = null
    var onCameraDisconnected: (() -> Unit)? = null
    var onCameraError: ((Int) -> Unit)? = null
    
    fun startBackgroundThread() {
        if (backgroundThread == null) {
            backgroundThread = HandlerThread("CameraBackground").also { it.start() }
            backgroundHandler = Handler(backgroundThread?.looper!!)
        }
    }
    
    fun stopBackgroundThread() {
        backgroundThread?.quitSafely()
        try {
            backgroundThread?.join()
            backgroundThread = null
            backgroundHandler = null
        } catch (e: InterruptedException) {
            Log.e(TAG, "Error stopping background thread", e)
        }
    }
    
    fun openCamera(isFront: Boolean = false, aspectRatio: CameraSettings.AspectRatio) {
        startBackgroundThread()
        isFrontCamera = isFront
        
        try {
            val cameraList = cameraManager.cameraIdList
            cameraId = if (isFrontCamera) {
                cameraList.find {
                    cameraManager.getCameraCharacteristics(it)
                        .get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
                } ?: cameraList[0]
            } else {
                cameraList.find {
                    cameraManager.getCameraCharacteristics(it)
                        .get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
                } ?: cameraList[0]
            }
            
            cameraId?.let { id ->
                val characteristics = cameraManager.getCameraCharacteristics(id)
                val map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
                
                val zoomRange = characteristics.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM)
                maxZoom = zoomRange ?: 1.0f
                
                val displaySize = context.resources.displayMetrics
                val targetAspect = when (aspectRatio) {
                    CameraSettings.AspectRatio.RATIO_16_9 -> 16f / 9f
                    CameraSettings.AspectRatio.RATIO_4_3 -> 4f / 3f
                    CameraSettings.AspectRatio.RATIO_1_1 -> 1f
                }
                
                val sizes = map.getOutputSizes(ImageReader::class.java)
                previewSize = sizes.sortedByDescending { it.width * it.height }
                    .firstOrNull {
                        val aspect = it.width.toFloat() / it.height.toFloat()
                        kotlin.math.abs(aspect - targetAspect) < 0.1f
                    } ?: sizes[0]
                
                if (ContextCompat.checkSelfPermission(
                        context,
                        android.Manifest.permission.CAMERA
                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                ) {
                    cameraManager.openCamera(id, stateCallback, backgroundHandler)
                }
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "Camera permission not granted", e)
        } catch (e: Exception) {
            Log.e(TAG, "Error opening camera", e)
        }
    }
    
    private val stateCallback = object : CameraDevice.StateCallback() {
        override fun onOpened(camera: CameraDevice) {
            cameraDevice = camera
            onCameraOpened?.invoke(camera)
        }
        
        override fun onDisconnected(camera: CameraDevice) {
            camera.close()
            cameraDevice = null
            onCameraDisconnected?.invoke()
        }
        
        override fun onError(camera: CameraDevice, error: Int) {
            camera.close()
            cameraDevice = null
            onCameraError?.invoke(error)
        }
    }
    
    fun getCameraDevice(): CameraDevice? = cameraDevice
    
    fun getBackgroundHandler(): Handler? = backgroundHandler
    
    fun closeCamera() {
        cameraDevice?.close()
        cameraDevice = null
        cameraId = null
    }
    
    companion object {
        private const val TAG = "CameraController"
    }
}

