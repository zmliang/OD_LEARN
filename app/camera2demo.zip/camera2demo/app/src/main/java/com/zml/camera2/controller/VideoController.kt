package com.zml.camera2.controller

import android.content.Context
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraCaptureSession
import android.media.MediaRecorder
import android.os.Environment
import android.os.Handler
import android.provider.MediaStore
import android.util.Log
import android.util.Size
import android.view.Surface
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * 录像控制器
 */
class VideoController(
    private val context: Context,
    private val backgroundHandler: Handler
) {
    
    private var mediaRecorder: MediaRecorder? = null
    private var videoFile: File? = null
    private var previewSize: Size? = null
    private var orientationHint: Int = 0
    
    var isRecording = false
        private set
    
    var onVideoRecorded: ((File) -> Unit)? = null
    
    fun initialize(previewSize: Size, orientationHint: Int) {
        this.previewSize = previewSize
        this.orientationHint = orientationHint
    }
    
    fun startRecording(): Surface? {
        if (isRecording) return null
        
        try {
            setupMediaRecorder()
            mediaRecorder?.start()
            isRecording = true
            return mediaRecorder?.surface
        } catch (e: Exception) {
            Log.e(TAG, "Error starting recording", e)
            releaseMediaRecorder()
            return null
        }
    }
    
    fun stopRecording() {
        if (!isRecording) return
        
        isRecording = false
        releaseMediaRecorder()
        videoFile?.let { onVideoRecorded?.invoke(it) }
    }
    
    private fun setupMediaRecorder() {
        releaseMediaRecorder()
        
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val filename = "VID_${timestamp}.mp4"
        
        videoFile = File(
            context.getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES) ?: context.filesDir,
            filename
        )
        
        mediaRecorder = MediaRecorder().apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setOutputFile(videoFile?.absolutePath)
            setVideoEncodingBitRate(10000000)
            setVideoFrameRate(30)
            setVideoSize(previewSize?.width ?: 1920, previewSize?.height ?: 1080)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setOrientationHint(orientationHint)
            try {
                prepare()
            } catch (e: Exception) {
                Log.e(TAG, "Error preparing MediaRecorder", e)
            }
        }
    }
    
    private fun releaseMediaRecorder() {
        try {
            if (isRecording) {
                mediaRecorder?.stop()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping MediaRecorder", e)
        }
        
        mediaRecorder?.reset()
        mediaRecorder?.release()
        mediaRecorder = null
        
        // Save video to MediaStore
        videoFile?.let { file ->
            if (file.exists()) {
                val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                val filename = "VID_${timestamp}.mp4"
                
                val contentValues = android.content.ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, filename)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                        put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_DCIM}/Camera")
                    }
                }
                
                try {
                    val uri = context.contentResolver.insert(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        contentValues
                    )
                    uri?.let {
                        context.contentResolver.openOutputStream(it)?.use { output ->
                            file.inputStream().use { input ->
                                input.copyTo(output)
                            }
                        }
                        file.delete()
                        videoFile = File(filename)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error saving video to MediaStore", e)
                }
            }
        }
    }
    
    fun close() {
        stopRecording()
    }
    
    companion object {
        private const val TAG = "VideoController"
    }
}

