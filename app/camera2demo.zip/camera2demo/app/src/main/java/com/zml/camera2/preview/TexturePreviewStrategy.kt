package com.zml.camera2.preview

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.SurfaceTexture
import android.view.TextureView
import android.view.View
import android.widget.FrameLayout
import com.zml.camera2.FaceRect
import com.zml.camera2.Filter

/**
 * 基于 TextureView 的预览策略实现
 */
class TexturePreviewStrategy(context: Context) : PreviewStrategy {
    
    private val containerView: FrameLayout = FrameLayout(context)
    private val textureView: TextureView = TextureView(context)
    private val overlayView: OverlayView = OverlayView(context)
    private var listener: PreviewStrategy.SurfaceTextureListener? = null
    
    init {
        // 设置TextureView和OverlayView的布局参数
        textureView.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        overlayView.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        overlayView.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        overlayView.isClickable = false // 不拦截触摸事件
        
        // 添加View到容器
        containerView.addView(textureView)
        containerView.addView(overlayView)
        
        textureView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(texture: SurfaceTexture, width: Int, height: Int) {
                listener?.onSurfaceTextureAvailable(texture, width, height)
            }
            
            override fun onSurfaceTextureSizeChanged(texture: SurfaceTexture, width: Int, height: Int) {
                listener?.onSurfaceTextureSizeChanged(texture, width, height)
            }
            
            override fun onSurfaceTextureDestroyed(texture: SurfaceTexture): Boolean {
                return listener?.onSurfaceTextureDestroyed(texture) ?: true
            }
            
            override fun onSurfaceTextureUpdated(texture: SurfaceTexture) {
                listener?.onSurfaceTextureUpdated(texture)
            }
        }
    }
    
    override fun getPreviewView(): View = containerView
    
    override fun setSurfaceTextureListener(listener: PreviewStrategy.SurfaceTextureListener) {
        this.listener = listener
    }
    
    override fun updateTexImage() {
        textureView.invalidate()
    }
    
    override fun setCameraTexture(textureId: Int) {
        // TextureView 不需要手动设置纹理ID
    }
    
    override fun setFilter(filter: Filter) {
        // TextureView 本身不支持滤镜，需要在GLSurfaceView中实现
    }
    
    override fun setFaces(faces: List<FaceRect>) {
        overlayView.setFaces(faces)
        overlayView.invalidate()
    }
    
    override fun setGridLines(show: Boolean) {
        overlayView.setGridLines(show)
        overlayView.invalidate()
    }
    
    override fun setZoom(zoom: Float) {
        textureView.scaleX = zoom
        textureView.scaleY = zoom
    }
    
    override fun setAspectRatio(width: Int, height: Int) {
        val aspectRatio = if (height != 0) width.toFloat() / height.toFloat() else 1.0f
        // TextureView的宽高比通过容器View控制
        containerView.post {
            val layoutParams = containerView.layoutParams
            if (layoutParams != null && aspectRatio > 0) {
                val containerWidth = containerView.width
                if (containerWidth > 0) {
                    layoutParams.height = (containerWidth / aspectRatio).toInt()
                    containerView.layoutParams = layoutParams
                }
            }
        }
    }
    
    fun getSurfaceTexture(): SurfaceTexture? = textureView.surfaceTexture
}


/**
 * 覆盖View，用于在TextureView上绘制网格线和人脸框
 * 注意：TextureView的draw()方法是final的，不能重写
 * 所以我们使用一个独立的覆盖View来绘制网格线和人脸框
 */
private class OverlayView(context: Context) : View(context) {
    
    private var faces: List<FaceRect> = emptyList()
    private var showGridLines = false
    
    fun setFaces(faces: List<FaceRect>) {
        this.faces = faces
    }
    
    fun setGridLines(show: Boolean) {
        this.showGridLines = show
    }
    
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        
        // 绘制网格线
        if (showGridLines) {
            drawGridLines(canvas)
        }
        
        // 绘制人脸框
        if (faces.isNotEmpty()) {
            drawFaceRects(canvas)
        }
    }
    
    private fun drawGridLines(canvas: Canvas) {
        val paint = Paint().apply {
            color = android.graphics.Color.WHITE
            alpha = 128
            strokeWidth = 2f
        }
        
        val width = width.toFloat()
        val height = height.toFloat()
        
        // 绘制三分线
        val thirdWidth = width / 3
        val thirdHeight = height / 3
        
        // 垂直线
        canvas.drawLine(thirdWidth, 0f, thirdWidth, height, paint)
        canvas.drawLine(thirdWidth * 2, 0f, thirdWidth * 2, height, paint)
        
        // 水平线
        canvas.drawLine(0f, thirdHeight, width, thirdHeight, paint)
        canvas.drawLine(0f, thirdHeight * 2, width, thirdHeight * 2, paint)
    }
    
    private fun drawFaceRects(canvas: Canvas) {
        val paint = Paint().apply {
            color = android.graphics.Color.GREEN
            style = Paint.Style.STROKE
            strokeWidth = 4f
        }
        
        val width = this.width.toFloat()
        val height = this.height.toFloat()
        
        faces.forEach { face ->
            val left = face.left * width
            val top = face.top * height
            val right = face.right * width
            val bottom = face.bottom * height
            
            canvas.drawRect(left, top, right, bottom, paint)
        }
    }
    
    init {
        // 设置为透明背景，不拦截触摸事件
        setBackgroundColor(android.graphics.Color.TRANSPARENT)
    }
}

