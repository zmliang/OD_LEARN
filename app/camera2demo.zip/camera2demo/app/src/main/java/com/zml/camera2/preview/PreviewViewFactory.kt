package com.zml.camera2.preview

import android.content.Context

/**
 * 预览View工厂类
 */
object PreviewViewFactory {
    
    enum class PreviewType {
        GL_SURFACE_VIEW,
        TEXTURE_VIEW
    }
    
    /**
     * 创建预览View
     */
    fun create(context: Context, type: PreviewType): IPreviewView {
        return when (type) {
            PreviewType.GL_SURFACE_VIEW -> GLSurfaceViewPreviewView(context)
            PreviewType.TEXTURE_VIEW -> TextureViewPreviewView(context)
        }
    }
    
    /**
     * 从配置创建预览View（可以从SharedPreferences或其他配置源读取）
     */
    fun createFromConfig(context: Context, defaultType: PreviewType = PreviewType.GL_SURFACE_VIEW): IPreviewView {
        // 这里可以从SharedPreferences读取配置
        // val savedType = context.getSharedPreferences("camera_prefs", Context.MODE_PRIVATE)
        //     .getString("preview_type", defaultType.name)
        // return create(context, PreviewType.valueOf(savedType))
        
        return create(context, defaultType)
    }
}

