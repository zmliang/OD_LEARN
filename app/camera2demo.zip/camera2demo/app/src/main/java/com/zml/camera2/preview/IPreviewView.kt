package com.zml.camera2.preview

import android.graphics.SurfaceTexture
import android.view.Surface
import android.view.View

/**
 * 预览View接口，支持不同的预览实现策略
 */
interface IPreviewView {
    
    /**
     * 获取实际的View
     */
    fun getView(): View
    
    /**
     * 设置SurfaceTexture准备回调
     */
    fun setSurfaceTextureListener(listener: SurfaceTextureListener)
    
    /**
     * 更新纹理图像
     */
    fun updateTexImage()
    
    /**
     * 获取SurfaceTexture
     */
    fun getSurfaceTexture(): SurfaceTexture?
    
    /**
     * 设置渲染回调
     */
    fun setRenderCallback(callback: RenderCallback?)
    
    /**
     * SurfaceTexture准备完成监听器
     */
    interface SurfaceTextureListener {
        fun onSurfaceTextureAvailable(textureId: Int)
    }
    
    /**
     * 渲染回调
     */
    interface RenderCallback {
        fun onFrameAvailable()
    }


}

